-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acknowledges`
--

DROP TABLE IF EXISTS `acknowledges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acknowledges` (
  `acknowledgeid` bigint unsigned NOT NULL,
  `userid` bigint unsigned NOT NULL,
  `eventid` bigint unsigned NOT NULL,
  `clock` int NOT NULL DEFAULT '0',
  `message` varchar(2048) NOT NULL DEFAULT '',
  `action` int NOT NULL DEFAULT '0',
  `old_severity` int NOT NULL DEFAULT '0',
  `new_severity` int NOT NULL DEFAULT '0',
  `suppress_until` int NOT NULL DEFAULT '0',
  `taskid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`acknowledgeid`),
  KEY `acknowledges_1` (`userid`),
  KEY `acknowledges_2` (`eventid`),
  KEY `acknowledges_3` (`clock`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acknowledges`
--

LOCK TABLES `acknowledges` WRITE;
/*!40000 ALTER TABLE `acknowledges` DISABLE KEYS */;
/*!40000 ALTER TABLE `acknowledges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `actions`
--

DROP TABLE IF EXISTS `actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `actions` (
  `actionid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `eventsource` int NOT NULL DEFAULT '0',
  `evaltype` int NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '0',
  `esc_period` varchar(255) NOT NULL DEFAULT '1h',
  `formula` varchar(1024) NOT NULL DEFAULT '',
  `pause_suppressed` int NOT NULL DEFAULT '1',
  `notify_if_canceled` int NOT NULL DEFAULT '1',
  `pause_symptoms` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`actionid`),
  UNIQUE KEY `actions_2` (`name`),
  KEY `actions_1` (`eventsource`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actions`
--

LOCK TABLES `actions` WRITE;
/*!40000 ALTER TABLE `actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alerts`
--

DROP TABLE IF EXISTS `alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alerts` (
  `alertid` bigint unsigned NOT NULL,
  `actionid` bigint unsigned NOT NULL,
  `eventid` bigint unsigned NOT NULL,
  `userid` bigint unsigned DEFAULT NULL,
  `clock` int NOT NULL DEFAULT '0',
  `mediatypeid` bigint unsigned DEFAULT NULL,
  `sendto` varchar(1024) NOT NULL DEFAULT '',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `status` int NOT NULL DEFAULT '0',
  `retries` int NOT NULL DEFAULT '0',
  `error` varchar(2048) NOT NULL DEFAULT '',
  `esc_step` int NOT NULL DEFAULT '0',
  `alerttype` int NOT NULL DEFAULT '0',
  `p_eventid` bigint unsigned DEFAULT NULL,
  `acknowledgeid` bigint unsigned DEFAULT NULL,
  `parameters` text NOT NULL,
  PRIMARY KEY (`alertid`),
  KEY `alerts_1` (`actionid`),
  KEY `alerts_2` (`clock`),
  KEY `alerts_3` (`eventid`),
  KEY `alerts_4` (`status`),
  KEY `alerts_5` (`mediatypeid`),
  KEY `alerts_6` (`userid`),
  KEY `alerts_7` (`p_eventid`),
  KEY `alerts_8` (`acknowledgeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alerts`
--

LOCK TABLES `alerts` WRITE;
/*!40000 ALTER TABLE `alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auditlog`
--

DROP TABLE IF EXISTS `auditlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auditlog` (
  `auditid` varchar(25) NOT NULL,
  `userid` bigint unsigned DEFAULT NULL,
  `username` varchar(100) NOT NULL DEFAULT '',
  `clock` int NOT NULL DEFAULT '0',
  `ip` varchar(39) NOT NULL DEFAULT '',
  `action` int NOT NULL DEFAULT '0',
  `resourcetype` int NOT NULL DEFAULT '0',
  `resourceid` bigint unsigned DEFAULT NULL,
  `resource_cuid` varchar(25) DEFAULT NULL,
  `resourcename` varchar(255) NOT NULL DEFAULT '',
  `recordsetid` varchar(25) NOT NULL,
  `details` longtext NOT NULL,
  PRIMARY KEY (`auditid`),
  KEY `auditlog_1` (`userid`,`clock`),
  KEY `auditlog_2` (`clock`),
  KEY `auditlog_3` (`resourcetype`,`resourceid`),
  KEY `auditlog_4` (`recordsetid`),
  KEY `auditlog_5` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditlog`
--

LOCK TABLES `auditlog` WRITE;
/*!40000 ALTER TABLE `auditlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `auditlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `autoreg_host`
--

DROP TABLE IF EXISTS `autoreg_host`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `autoreg_host` (
  `autoreg_hostid` bigint unsigned NOT NULL,
  `proxyid` bigint unsigned DEFAULT NULL,
  `host` varchar(128) NOT NULL DEFAULT '',
  `listen_ip` varchar(39) NOT NULL DEFAULT '',
  `listen_port` int NOT NULL DEFAULT '0',
  `listen_dns` varchar(255) NOT NULL DEFAULT '',
  `host_metadata` text NOT NULL,
  `flags` int NOT NULL DEFAULT '0',
  `tls_accepted` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`autoreg_hostid`),
  KEY `autoreg_host_1` (`host`),
  KEY `autoreg_host_2` (`proxyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autoreg_host`
--

LOCK TABLES `autoreg_host` WRITE;
/*!40000 ALTER TABLE `autoreg_host` DISABLE KEYS */;
/*!40000 ALTER TABLE `autoreg_host` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changelog`
--

DROP TABLE IF EXISTS `changelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changelog` (
  `changelogid` bigint unsigned NOT NULL AUTO_INCREMENT,
  `object` int NOT NULL DEFAULT '0',
  `objectid` bigint unsigned NOT NULL,
  `operation` int NOT NULL DEFAULT '0',
  `clock` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`changelogid`),
  KEY `changelog_1` (`clock`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changelog`
--

LOCK TABLES `changelog` WRITE;
/*!40000 ALTER TABLE `changelog` DISABLE KEYS */;
/*!40000 ALTER TABLE `changelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conditions`
--

DROP TABLE IF EXISTS `conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conditions` (
  `conditionid` bigint unsigned NOT NULL,
  `actionid` bigint unsigned NOT NULL,
  `conditiontype` int NOT NULL DEFAULT '0',
  `operator` int NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  `value2` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`conditionid`),
  KEY `conditions_1` (`actionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conditions`
--

LOCK TABLES `conditions` WRITE;
/*!40000 ALTER TABLE `conditions` DISABLE KEYS */;
/*!40000 ALTER TABLE `conditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_autoreg_tls`
--

DROP TABLE IF EXISTS `config_autoreg_tls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_autoreg_tls` (
  `autoreg_tlsid` bigint unsigned NOT NULL,
  `tls_psk_identity` varchar(128) NOT NULL DEFAULT '',
  `tls_psk` varchar(512) NOT NULL DEFAULT '',
  PRIMARY KEY (`autoreg_tlsid`),
  UNIQUE KEY `config_autoreg_tls_1` (`tls_psk_identity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_autoreg_tls`
--

LOCK TABLES `config_autoreg_tls` WRITE;
/*!40000 ALTER TABLE `config_autoreg_tls` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_autoreg_tls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `connector`
--

DROP TABLE IF EXISTS `connector`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `connector` (
  `connectorid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `protocol` int NOT NULL DEFAULT '0',
  `data_type` int NOT NULL DEFAULT '0',
  `url` varchar(2048) NOT NULL DEFAULT '',
  `max_records` int NOT NULL DEFAULT '0',
  `max_senders` int NOT NULL DEFAULT '1',
  `max_attempts` int NOT NULL DEFAULT '1',
  `timeout` varchar(255) NOT NULL DEFAULT '5s',
  `http_proxy` varchar(255) NOT NULL DEFAULT '',
  `authtype` int NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `token` varchar(128) NOT NULL DEFAULT '',
  `verify_peer` int NOT NULL DEFAULT '1',
  `verify_host` int NOT NULL DEFAULT '1',
  `ssl_cert_file` varchar(255) NOT NULL DEFAULT '',
  `ssl_key_file` varchar(255) NOT NULL DEFAULT '',
  `ssl_key_password` varchar(64) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `status` int NOT NULL DEFAULT '1',
  `tags_evaltype` int NOT NULL DEFAULT '0',
  `item_value_type` int NOT NULL DEFAULT '31',
  `attempt_interval` varchar(32) NOT NULL DEFAULT '5s',
  PRIMARY KEY (`connectorid`),
  UNIQUE KEY `connector_1` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `connector`
--

LOCK TABLES `connector` WRITE;
/*!40000 ALTER TABLE `connector` DISABLE KEYS */;
/*!40000 ALTER TABLE `connector` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `connector_tag`
--

DROP TABLE IF EXISTS `connector_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `connector_tag` (
  `connector_tagid` bigint unsigned NOT NULL,
  `connectorid` bigint unsigned NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `operator` int NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`connector_tagid`),
  KEY `connector_tag_1` (`connectorid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `connector_tag`
--

LOCK TABLES `connector_tag` WRITE;
/*!40000 ALTER TABLE `connector_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `connector_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corr_condition`
--

DROP TABLE IF EXISTS `corr_condition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `corr_condition` (
  `corr_conditionid` bigint unsigned NOT NULL,
  `correlationid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`corr_conditionid`),
  KEY `corr_condition_1` (`correlationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corr_condition`
--

LOCK TABLES `corr_condition` WRITE;
/*!40000 ALTER TABLE `corr_condition` DISABLE KEYS */;
/*!40000 ALTER TABLE `corr_condition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corr_condition_group`
--

DROP TABLE IF EXISTS `corr_condition_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `corr_condition_group` (
  `corr_conditionid` bigint unsigned NOT NULL,
  `operator` int NOT NULL DEFAULT '0',
  `groupid` bigint unsigned NOT NULL,
  PRIMARY KEY (`corr_conditionid`),
  KEY `corr_condition_group_1` (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corr_condition_group`
--

LOCK TABLES `corr_condition_group` WRITE;
/*!40000 ALTER TABLE `corr_condition_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `corr_condition_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corr_condition_tag`
--

DROP TABLE IF EXISTS `corr_condition_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `corr_condition_tag` (
  `corr_conditionid` bigint unsigned NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`corr_conditionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corr_condition_tag`
--

LOCK TABLES `corr_condition_tag` WRITE;
/*!40000 ALTER TABLE `corr_condition_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `corr_condition_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corr_condition_tagpair`
--

DROP TABLE IF EXISTS `corr_condition_tagpair`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `corr_condition_tagpair` (
  `corr_conditionid` bigint unsigned NOT NULL,
  `oldtag` varchar(255) NOT NULL DEFAULT '',
  `newtag` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`corr_conditionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corr_condition_tagpair`
--

LOCK TABLES `corr_condition_tagpair` WRITE;
/*!40000 ALTER TABLE `corr_condition_tagpair` DISABLE KEYS */;
/*!40000 ALTER TABLE `corr_condition_tagpair` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corr_condition_tagvalue`
--

DROP TABLE IF EXISTS `corr_condition_tagvalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `corr_condition_tagvalue` (
  `corr_conditionid` bigint unsigned NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `operator` int NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`corr_conditionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corr_condition_tagvalue`
--

LOCK TABLES `corr_condition_tagvalue` WRITE;
/*!40000 ALTER TABLE `corr_condition_tagvalue` DISABLE KEYS */;
/*!40000 ALTER TABLE `corr_condition_tagvalue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corr_operation`
--

DROP TABLE IF EXISTS `corr_operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `corr_operation` (
  `corr_operationid` bigint unsigned NOT NULL,
  `correlationid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`corr_operationid`),
  KEY `corr_operation_1` (`correlationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corr_operation`
--

LOCK TABLES `corr_operation` WRITE;
/*!40000 ALTER TABLE `corr_operation` DISABLE KEYS */;
/*!40000 ALTER TABLE `corr_operation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `correlation`
--

DROP TABLE IF EXISTS `correlation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `correlation` (
  `correlationid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `evaltype` int NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '0',
  `formula` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`correlationid`),
  UNIQUE KEY `correlation_2` (`name`),
  KEY `correlation_1` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `correlation`
--

LOCK TABLES `correlation` WRITE;
/*!40000 ALTER TABLE `correlation` DISABLE KEYS */;
/*!40000 ALTER TABLE `correlation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard`
--

DROP TABLE IF EXISTS `dashboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard` (
  `dashboardid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `userid` bigint unsigned DEFAULT NULL,
  `private` int NOT NULL DEFAULT '1',
  `templateid` bigint unsigned DEFAULT NULL,
  `display_period` int NOT NULL DEFAULT '30',
  `auto_start` int NOT NULL DEFAULT '1',
  `uuid` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`dashboardid`),
  KEY `dashboard_1` (`userid`),
  KEY `dashboard_2` (`templateid`),
  KEY `dashboard_3` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard`
--

LOCK TABLES `dashboard` WRITE;
/*!40000 ALTER TABLE `dashboard` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_page`
--

DROP TABLE IF EXISTS `dashboard_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_page` (
  `dashboard_pageid` bigint unsigned NOT NULL,
  `dashboardid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `display_period` int NOT NULL DEFAULT '0',
  `sortorder` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`dashboard_pageid`),
  KEY `dashboard_page_1` (`dashboardid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_page`
--

LOCK TABLES `dashboard_page` WRITE;
/*!40000 ALTER TABLE `dashboard_page` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_user`
--

DROP TABLE IF EXISTS `dashboard_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_user` (
  `dashboard_userid` bigint unsigned NOT NULL,
  `dashboardid` bigint unsigned NOT NULL,
  `userid` bigint unsigned NOT NULL,
  `permission` int NOT NULL DEFAULT '2',
  PRIMARY KEY (`dashboard_userid`),
  UNIQUE KEY `dashboard_user_1` (`dashboardid`,`userid`),
  KEY `dashboard_user_2` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_user`
--

LOCK TABLES `dashboard_user` WRITE;
/*!40000 ALTER TABLE `dashboard_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_usrgrp`
--

DROP TABLE IF EXISTS `dashboard_usrgrp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_usrgrp` (
  `dashboard_usrgrpid` bigint unsigned NOT NULL,
  `dashboardid` bigint unsigned NOT NULL,
  `usrgrpid` bigint unsigned NOT NULL,
  `permission` int NOT NULL DEFAULT '2',
  PRIMARY KEY (`dashboard_usrgrpid`),
  UNIQUE KEY `dashboard_usrgrp_1` (`dashboardid`,`usrgrpid`),
  KEY `dashboard_usrgrp_2` (`usrgrpid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_usrgrp`
--

LOCK TABLES `dashboard_usrgrp` WRITE;
/*!40000 ALTER TABLE `dashboard_usrgrp` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_usrgrp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbversion`
--

DROP TABLE IF EXISTS `dbversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dbversion` (
  `dbversionid` bigint unsigned NOT NULL,
  `mandatory` int NOT NULL DEFAULT '0',
  `optional` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`dbversionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbversion`
--

LOCK TABLES `dbversion` WRITE;
/*!40000 ALTER TABLE `dbversion` DISABLE KEYS */;
INSERT INTO `dbversion` VALUES (1,7040000,7040010);
/*!40000 ALTER TABLE `dbversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dchecks`
--

DROP TABLE IF EXISTS `dchecks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dchecks` (
  `dcheckid` bigint unsigned NOT NULL,
  `druleid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `key_` varchar(2048) NOT NULL DEFAULT '',
  `snmp_community` varchar(255) NOT NULL DEFAULT '',
  `ports` varchar(255) NOT NULL DEFAULT '0',
  `snmpv3_securityname` varchar(64) NOT NULL DEFAULT '',
  `snmpv3_securitylevel` int NOT NULL DEFAULT '0',
  `snmpv3_authpassphrase` varchar(64) NOT NULL DEFAULT '',
  `snmpv3_privpassphrase` varchar(64) NOT NULL DEFAULT '',
  `uniq` int NOT NULL DEFAULT '0',
  `snmpv3_authprotocol` int NOT NULL DEFAULT '0',
  `snmpv3_privprotocol` int NOT NULL DEFAULT '0',
  `snmpv3_contextname` varchar(255) NOT NULL DEFAULT '',
  `host_source` int NOT NULL DEFAULT '1',
  `name_source` int NOT NULL DEFAULT '0',
  `allow_redirect` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`dcheckid`),
  KEY `dchecks_1` (`druleid`,`host_source`,`name_source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dchecks`
--

LOCK TABLES `dchecks` WRITE;
/*!40000 ALTER TABLE `dchecks` DISABLE KEYS */;
/*!40000 ALTER TABLE `dchecks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dhosts`
--

DROP TABLE IF EXISTS `dhosts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dhosts` (
  `dhostid` bigint unsigned NOT NULL,
  `druleid` bigint unsigned NOT NULL,
  `status` int NOT NULL DEFAULT '0',
  `lastup` int NOT NULL DEFAULT '0',
  `lastdown` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`dhostid`),
  KEY `dhosts_1` (`druleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dhosts`
--

LOCK TABLES `dhosts` WRITE;
/*!40000 ALTER TABLE `dhosts` DISABLE KEYS */;
/*!40000 ALTER TABLE `dhosts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drules`
--

DROP TABLE IF EXISTS `drules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drules` (
  `druleid` bigint unsigned NOT NULL,
  `proxyid` bigint unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `iprange` varchar(2048) NOT NULL DEFAULT '',
  `delay` varchar(255) NOT NULL DEFAULT '1h',
  `status` int NOT NULL DEFAULT '0',
  `concurrency_max` int NOT NULL DEFAULT '0',
  `error` varchar(2048) NOT NULL DEFAULT '',
  PRIMARY KEY (`druleid`),
  UNIQUE KEY `drules_2` (`name`),
  KEY `drules_1` (`proxyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drules`
--

LOCK TABLES `drules` WRITE;
/*!40000 ALTER TABLE `drules` DISABLE KEYS */;
/*!40000 ALTER TABLE `drules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dservices`
--

DROP TABLE IF EXISTS `dservices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dservices` (
  `dserviceid` bigint unsigned NOT NULL,
  `dhostid` bigint unsigned NOT NULL,
  `value` varchar(255) NOT NULL DEFAULT '',
  `port` int NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '0',
  `lastup` int NOT NULL DEFAULT '0',
  `lastdown` int NOT NULL DEFAULT '0',
  `dcheckid` bigint unsigned NOT NULL,
  `ip` varchar(39) NOT NULL DEFAULT '',
  `dns` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`dserviceid`),
  UNIQUE KEY `dservices_1` (`dcheckid`,`ip`,`port`),
  KEY `dservices_2` (`dhostid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dservices`
--

LOCK TABLES `dservices` WRITE;
/*!40000 ALTER TABLE `dservices` DISABLE KEYS */;
/*!40000 ALTER TABLE `dservices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `escalations`
--

DROP TABLE IF EXISTS `escalations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `escalations` (
  `escalationid` bigint unsigned NOT NULL,
  `actionid` bigint unsigned NOT NULL,
  `triggerid` bigint unsigned DEFAULT NULL,
  `eventid` bigint unsigned DEFAULT NULL,
  `r_eventid` bigint unsigned DEFAULT NULL,
  `nextcheck` int NOT NULL DEFAULT '0',
  `esc_step` int NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '0',
  `itemid` bigint unsigned DEFAULT NULL,
  `acknowledgeid` bigint unsigned DEFAULT NULL,
  `servicealarmid` bigint unsigned DEFAULT NULL,
  `serviceid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`escalationid`),
  UNIQUE KEY `escalations_1` (`triggerid`,`itemid`,`serviceid`,`escalationid`),
  KEY `escalations_2` (`eventid`),
  KEY `escalations_3` (`nextcheck`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `escalations`
--

LOCK TABLES `escalations` WRITE;
/*!40000 ALTER TABLE `escalations` DISABLE KEYS */;
/*!40000 ALTER TABLE `escalations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_recovery`
--

DROP TABLE IF EXISTS `event_recovery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_recovery` (
  `eventid` bigint unsigned NOT NULL,
  `r_eventid` bigint unsigned NOT NULL,
  `c_eventid` bigint unsigned DEFAULT NULL,
  `correlationid` bigint unsigned DEFAULT NULL,
  `userid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`eventid`),
  KEY `event_recovery_1` (`r_eventid`),
  KEY `event_recovery_2` (`c_eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_recovery`
--

LOCK TABLES `event_recovery` WRITE;
/*!40000 ALTER TABLE `event_recovery` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_recovery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_suppress`
--

DROP TABLE IF EXISTS `event_suppress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_suppress` (
  `event_suppressid` bigint unsigned NOT NULL,
  `eventid` bigint unsigned NOT NULL,
  `maintenanceid` bigint unsigned DEFAULT NULL,
  `suppress_until` int NOT NULL DEFAULT '0',
  `userid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`event_suppressid`),
  UNIQUE KEY `event_suppress_1` (`eventid`,`maintenanceid`),
  KEY `event_suppress_2` (`suppress_until`),
  KEY `event_suppress_3` (`maintenanceid`),
  KEY `event_suppress_4` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_suppress`
--

LOCK TABLES `event_suppress` WRITE;
/*!40000 ALTER TABLE `event_suppress` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_suppress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_symptom`
--

DROP TABLE IF EXISTS `event_symptom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_symptom` (
  `eventid` bigint unsigned NOT NULL,
  `cause_eventid` bigint unsigned NOT NULL,
  PRIMARY KEY (`eventid`),
  KEY `event_symptom_1` (`cause_eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_symptom`
--

LOCK TABLES `event_symptom` WRITE;
/*!40000 ALTER TABLE `event_symptom` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_symptom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_tag`
--

DROP TABLE IF EXISTS `event_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_tag` (
  `eventtagid` bigint unsigned NOT NULL,
  `eventid` bigint unsigned NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`eventtagid`),
  KEY `event_tag_1` (`eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_tag`
--

LOCK TABLES `event_tag` WRITE;
/*!40000 ALTER TABLE `event_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `eventid` bigint unsigned NOT NULL,
  `source` int NOT NULL DEFAULT '0',
  `object` int NOT NULL DEFAULT '0',
  `objectid` bigint unsigned NOT NULL DEFAULT '0',
  `clock` int NOT NULL DEFAULT '0',
  `value` int NOT NULL DEFAULT '0',
  `acknowledged` int NOT NULL DEFAULT '0',
  `ns` int NOT NULL DEFAULT '0',
  `name` varchar(2048) NOT NULL DEFAULT '',
  `severity` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`eventid`),
  KEY `events_1` (`source`,`object`,`objectid`,`clock`),
  KEY `events_2` (`source`,`object`,`clock`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expressions`
--

DROP TABLE IF EXISTS `expressions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expressions` (
  `expressionid` bigint unsigned NOT NULL,
  `regexpid` bigint unsigned NOT NULL,
  `expression` varchar(255) NOT NULL DEFAULT '',
  `expression_type` int NOT NULL DEFAULT '0',
  `exp_delimiter` varchar(1) NOT NULL DEFAULT '',
  `case_sensitive` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`expressionid`),
  KEY `expressions_1` (`regexpid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expressions`
--

LOCK TABLES `expressions` WRITE;
/*!40000 ALTER TABLE `expressions` DISABLE KEYS */;
/*!40000 ALTER TABLE `expressions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `functions`
--

DROP TABLE IF EXISTS `functions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `functions` (
  `functionid` bigint unsigned NOT NULL,
  `itemid` bigint unsigned NOT NULL,
  `triggerid` bigint unsigned NOT NULL,
  `name` varchar(12) NOT NULL DEFAULT '',
  `parameter` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`functionid`),
  KEY `functions_1` (`triggerid`),
  KEY `functions_2` (`itemid`,`name`,`parameter`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `functions`
--

LOCK TABLES `functions` WRITE;
/*!40000 ALTER TABLE `functions` DISABLE KEYS */;
/*!40000 ALTER TABLE `functions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalmacro`
--

DROP TABLE IF EXISTS `globalmacro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalmacro` (
  `globalmacroid` bigint unsigned NOT NULL,
  `macro` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(2048) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`globalmacroid`),
  UNIQUE KEY `globalmacro_1` (`macro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalmacro`
--

LOCK TABLES `globalmacro` WRITE;
/*!40000 ALTER TABLE `globalmacro` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalmacro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalvars`
--

DROP TABLE IF EXISTS `globalvars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalvars` (
  `name` varchar(64) NOT NULL DEFAULT '',
  `value` varchar(2048) NOT NULL DEFAULT '',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalvars`
--

LOCK TABLES `globalvars` WRITE;
/*!40000 ALTER TABLE `globalvars` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalvars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `graph_discovery`
--

DROP TABLE IF EXISTS `graph_discovery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `graph_discovery` (
  `graphid` bigint unsigned NOT NULL,
  `parent_graphid` bigint unsigned NOT NULL,
  `lastcheck` int NOT NULL DEFAULT '0',
  `ts_delete` int NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`graphid`),
  KEY `graph_discovery_1` (`parent_graphid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `graph_discovery`
--

LOCK TABLES `graph_discovery` WRITE;
/*!40000 ALTER TABLE `graph_discovery` DISABLE KEYS */;
/*!40000 ALTER TABLE `graph_discovery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `graph_theme`
--

DROP TABLE IF EXISTS `graph_theme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `graph_theme` (
  `graphthemeid` bigint unsigned NOT NULL,
  `theme` varchar(64) NOT NULL DEFAULT '',
  `backgroundcolor` varchar(6) NOT NULL DEFAULT '',
  `graphcolor` varchar(6) NOT NULL DEFAULT '',
  `gridcolor` varchar(6) NOT NULL DEFAULT '',
  `maingridcolor` varchar(6) NOT NULL DEFAULT '',
  `gridbordercolor` varchar(6) NOT NULL DEFAULT '',
  `textcolor` varchar(6) NOT NULL DEFAULT '',
  `highlightcolor` varchar(6) NOT NULL DEFAULT '',
  `leftpercentilecolor` varchar(6) NOT NULL DEFAULT '',
  `rightpercentilecolor` varchar(6) NOT NULL DEFAULT '',
  `nonworktimecolor` varchar(6) NOT NULL DEFAULT '',
  `colorpalette` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`graphthemeid`),
  UNIQUE KEY `graph_theme_1` (`theme`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `graph_theme`
--

LOCK TABLES `graph_theme` WRITE;
/*!40000 ALTER TABLE `graph_theme` DISABLE KEYS */;
/*!40000 ALTER TABLE `graph_theme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `graphs`
--

DROP TABLE IF EXISTS `graphs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `graphs` (
  `graphid` bigint unsigned NOT NULL,
  `name` varchar(128) NOT NULL DEFAULT '',
  `width` int NOT NULL DEFAULT '900',
  `height` int NOT NULL DEFAULT '200',
  `yaxismin` double NOT NULL DEFAULT '0',
  `yaxismax` double NOT NULL DEFAULT '100',
  `templateid` bigint unsigned DEFAULT NULL,
  `show_work_period` int NOT NULL DEFAULT '1',
  `show_triggers` int NOT NULL DEFAULT '1',
  `graphtype` int NOT NULL DEFAULT '0',
  `show_legend` int NOT NULL DEFAULT '1',
  `show_3d` int NOT NULL DEFAULT '0',
  `percent_left` double NOT NULL DEFAULT '0',
  `percent_right` double NOT NULL DEFAULT '0',
  `ymin_type` int NOT NULL DEFAULT '0',
  `ymax_type` int NOT NULL DEFAULT '0',
  `ymin_itemid` bigint unsigned DEFAULT NULL,
  `ymax_itemid` bigint unsigned DEFAULT NULL,
  `flags` int NOT NULL DEFAULT '0',
  `discover` int NOT NULL DEFAULT '0',
  `uuid` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`graphid`),
  KEY `graphs_1` (`name`),
  KEY `graphs_2` (`templateid`),
  KEY `graphs_3` (`ymin_itemid`),
  KEY `graphs_4` (`ymax_itemid`),
  KEY `graphs_5` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `graphs`
--

LOCK TABLES `graphs` WRITE;
/*!40000 ALTER TABLE `graphs` DISABLE KEYS */;
/*!40000 ALTER TABLE `graphs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `graphs_items`
--

DROP TABLE IF EXISTS `graphs_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `graphs_items` (
  `gitemid` bigint unsigned NOT NULL,
  `graphid` bigint unsigned NOT NULL,
  `itemid` bigint unsigned NOT NULL,
  `drawtype` int NOT NULL DEFAULT '0',
  `sortorder` int NOT NULL DEFAULT '0',
  `color` varchar(6) NOT NULL DEFAULT '009600',
  `yaxisside` int NOT NULL DEFAULT '0',
  `calc_fnc` int NOT NULL DEFAULT '2',
  `type` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`gitemid`),
  KEY `graphs_items_1` (`itemid`),
  KEY `graphs_items_2` (`graphid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `graphs_items`
--

LOCK TABLES `graphs_items` WRITE;
/*!40000 ALTER TABLE `graphs_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `graphs_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_discovery`
--

DROP TABLE IF EXISTS `group_discovery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_discovery` (
  `groupdiscoveryid` bigint unsigned NOT NULL,
  `groupid` bigint unsigned NOT NULL,
  `parent_group_prototypeid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `lastcheck` int NOT NULL DEFAULT '0',
  `ts_delete` int NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`groupdiscoveryid`),
  UNIQUE KEY `group_discovery_1` (`groupid`,`parent_group_prototypeid`),
  KEY `group_discovery_2` (`parent_group_prototypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_discovery`
--

LOCK TABLES `group_discovery` WRITE;
/*!40000 ALTER TABLE `group_discovery` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_discovery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_prototype`
--

DROP TABLE IF EXISTS `group_prototype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_prototype` (
  `group_prototypeid` bigint unsigned NOT NULL,
  `hostid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `groupid` bigint unsigned DEFAULT NULL,
  `templateid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`group_prototypeid`),
  KEY `group_prototype_1` (`hostid`),
  KEY `group_prototype_2` (`groupid`),
  KEY `group_prototype_3` (`templateid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_prototype`
--

LOCK TABLES `group_prototype` WRITE;
/*!40000 ALTER TABLE `group_prototype` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_prototype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ha_node`
--

DROP TABLE IF EXISTS `ha_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ha_node` (
  `ha_nodeid` varchar(25) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `port` int NOT NULL DEFAULT '10051',
  `lastaccess` int NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '0',
  `ha_sessionid` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`ha_nodeid`),
  UNIQUE KEY `ha_node_1` (`name`),
  KEY `ha_node_2` (`status`,`lastaccess`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ha_node`
--

LOCK TABLES `ha_node` WRITE;
/*!40000 ALTER TABLE `ha_node` DISABLE KEYS */;
/*!40000 ALTER TABLE `ha_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hgset`
--

DROP TABLE IF EXISTS `hgset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hgset` (
  `hgsetid` bigint unsigned NOT NULL,
  `hash` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`hgsetid`),
  KEY `hgset_1` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hgset`
--

LOCK TABLES `hgset` WRITE;
/*!40000 ALTER TABLE `hgset` DISABLE KEYS */;
/*!40000 ALTER TABLE `hgset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hgset_group`
--

DROP TABLE IF EXISTS `hgset_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hgset_group` (
  `hgsetid` bigint unsigned NOT NULL,
  `groupid` bigint unsigned NOT NULL,
  PRIMARY KEY (`hgsetid`,`groupid`),
  KEY `hgset_group_1` (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hgset_group`
--

LOCK TABLES `hgset_group` WRITE;
/*!40000 ALTER TABLE `hgset_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `hgset_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `history` (
  `itemid` bigint unsigned NOT NULL,
  `clock` int NOT NULL DEFAULT '0',
  `value` double NOT NULL DEFAULT '0',
  `ns` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`,`clock`,`ns`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history`
--

LOCK TABLES `history` WRITE;
/*!40000 ALTER TABLE `history` DISABLE KEYS */;
/*!40000 ALTER TABLE `history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history_bin`
--

DROP TABLE IF EXISTS `history_bin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `history_bin` (
  `itemid` bigint unsigned NOT NULL,
  `clock` int NOT NULL DEFAULT '0',
  `ns` int NOT NULL DEFAULT '0',
  `value` longblob NOT NULL,
  PRIMARY KEY (`itemid`,`clock`,`ns`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history_bin`
--

LOCK TABLES `history_bin` WRITE;
/*!40000 ALTER TABLE `history_bin` DISABLE KEYS */;
/*!40000 ALTER TABLE `history_bin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history_log`
--

DROP TABLE IF EXISTS `history_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `history_log` (
  `itemid` bigint unsigned NOT NULL,
  `clock` int NOT NULL DEFAULT '0',
  `timestamp` int NOT NULL DEFAULT '0',
  `source` varchar(64) NOT NULL DEFAULT '',
  `severity` int NOT NULL DEFAULT '0',
  `value` text NOT NULL,
  `logeventid` int NOT NULL DEFAULT '0',
  `ns` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`,`clock`,`ns`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history_log`
--

LOCK TABLES `history_log` WRITE;
/*!40000 ALTER TABLE `history_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `history_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history_str`
--

DROP TABLE IF EXISTS `history_str`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `history_str` (
  `itemid` bigint unsigned NOT NULL,
  `clock` int NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  `ns` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`,`clock`,`ns`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history_str`
--

LOCK TABLES `history_str` WRITE;
/*!40000 ALTER TABLE `history_str` DISABLE KEYS */;
/*!40000 ALTER TABLE `history_str` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history_text`
--

DROP TABLE IF EXISTS `history_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `history_text` (
  `itemid` bigint unsigned NOT NULL,
  `clock` int NOT NULL DEFAULT '0',
  `value` text NOT NULL,
  `ns` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`,`clock`,`ns`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history_text`
--

LOCK TABLES `history_text` WRITE;
/*!40000 ALTER TABLE `history_text` DISABLE KEYS */;
/*!40000 ALTER TABLE `history_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history_uint`
--

DROP TABLE IF EXISTS `history_uint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `history_uint` (
  `itemid` bigint unsigned NOT NULL,
  `clock` int NOT NULL DEFAULT '0',
  `value` bigint unsigned NOT NULL DEFAULT '0',
  `ns` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`,`clock`,`ns`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history_uint`
--

LOCK TABLES `history_uint` WRITE;
/*!40000 ALTER TABLE `history_uint` DISABLE KEYS */;
/*!40000 ALTER TABLE `history_uint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `host_discovery`
--

DROP TABLE IF EXISTS `host_discovery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `host_discovery` (
  `hostid` bigint unsigned NOT NULL,
  `parent_hostid` bigint unsigned DEFAULT NULL,
  `lldruleid` bigint unsigned DEFAULT NULL,
  `host` varchar(128) NOT NULL DEFAULT '',
  `lastcheck` int NOT NULL DEFAULT '0',
  `ts_delete` int NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '0',
  `disable_source` int NOT NULL DEFAULT '0',
  `ts_disable` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`hostid`),
  KEY `host_discovery_1` (`parent_hostid`),
  KEY `host_discovery_2` (`lldruleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `host_discovery`
--

LOCK TABLES `host_discovery` WRITE;
/*!40000 ALTER TABLE `host_discovery` DISABLE KEYS */;
/*!40000 ALTER TABLE `host_discovery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `host_hgset`
--

DROP TABLE IF EXISTS `host_hgset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `host_hgset` (
  `hostid` bigint unsigned NOT NULL,
  `hgsetid` bigint unsigned NOT NULL,
  PRIMARY KEY (`hostid`),
  KEY `host_hgset_1` (`hgsetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `host_hgset`
--

LOCK TABLES `host_hgset` WRITE;
/*!40000 ALTER TABLE `host_hgset` DISABLE KEYS */;
/*!40000 ALTER TABLE `host_hgset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `host_inventory`
--

DROP TABLE IF EXISTS `host_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `host_inventory` (
  `hostid` bigint unsigned NOT NULL,
  `inventory_mode` int NOT NULL DEFAULT '0',
  `type` varchar(64) NOT NULL DEFAULT '',
  `type_full` varchar(64) NOT NULL DEFAULT '',
  `name` varchar(128) NOT NULL DEFAULT '',
  `alias` varchar(128) NOT NULL DEFAULT '',
  `os` varchar(128) NOT NULL DEFAULT '',
  `os_full` varchar(255) NOT NULL DEFAULT '',
  `os_short` varchar(128) NOT NULL DEFAULT '',
  `serialno_a` varchar(64) NOT NULL DEFAULT '',
  `serialno_b` varchar(64) NOT NULL DEFAULT '',
  `tag` varchar(64) NOT NULL DEFAULT '',
  `asset_tag` varchar(64) NOT NULL DEFAULT '',
  `macaddress_a` varchar(64) NOT NULL DEFAULT '',
  `macaddress_b` varchar(64) NOT NULL DEFAULT '',
  `hardware` varchar(255) NOT NULL DEFAULT '',
  `hardware_full` text NOT NULL,
  `software` varchar(255) NOT NULL DEFAULT '',
  `software_full` text NOT NULL,
  `software_app_a` varchar(64) NOT NULL DEFAULT '',
  `software_app_b` varchar(64) NOT NULL DEFAULT '',
  `software_app_c` varchar(64) NOT NULL DEFAULT '',
  `software_app_d` varchar(64) NOT NULL DEFAULT '',
  `software_app_e` varchar(64) NOT NULL DEFAULT '',
  `contact` text NOT NULL,
  `location` text NOT NULL,
  `location_lat` varchar(16) NOT NULL DEFAULT '',
  `location_lon` varchar(16) NOT NULL DEFAULT '',
  `notes` text NOT NULL,
  `chassis` varchar(64) NOT NULL DEFAULT '',
  `model` varchar(64) NOT NULL DEFAULT '',
  `hw_arch` varchar(32) NOT NULL DEFAULT '',
  `vendor` varchar(64) NOT NULL DEFAULT '',
  `contract_number` varchar(64) NOT NULL DEFAULT '',
  `installer_name` varchar(64) NOT NULL DEFAULT '',
  `deployment_status` varchar(64) NOT NULL DEFAULT '',
  `url_a` varchar(2048) NOT NULL DEFAULT '',
  `url_b` varchar(2048) NOT NULL DEFAULT '',
  `url_c` varchar(2048) NOT NULL DEFAULT '',
  `host_networks` text NOT NULL,
  `host_netmask` varchar(39) NOT NULL DEFAULT '',
  `host_router` varchar(39) NOT NULL DEFAULT '',
  `oob_ip` varchar(39) NOT NULL DEFAULT '',
  `oob_netmask` varchar(39) NOT NULL DEFAULT '',
  `oob_router` varchar(39) NOT NULL DEFAULT '',
  `date_hw_purchase` varchar(64) NOT NULL DEFAULT '',
  `date_hw_install` varchar(64) NOT NULL DEFAULT '',
  `date_hw_expiry` varchar(64) NOT NULL DEFAULT '',
  `date_hw_decomm` varchar(64) NOT NULL DEFAULT '',
  `site_address_a` varchar(128) NOT NULL DEFAULT '',
  `site_address_b` varchar(128) NOT NULL DEFAULT '',
  `site_address_c` varchar(128) NOT NULL DEFAULT '',
  `site_city` varchar(128) NOT NULL DEFAULT '',
  `site_state` varchar(64) NOT NULL DEFAULT '',
  `site_country` varchar(64) NOT NULL DEFAULT '',
  `site_zip` varchar(64) NOT NULL DEFAULT '',
  `site_rack` varchar(128) NOT NULL DEFAULT '',
  `site_notes` text NOT NULL,
  `poc_1_name` varchar(128) NOT NULL DEFAULT '',
  `poc_1_email` varchar(128) NOT NULL DEFAULT '',
  `poc_1_phone_a` varchar(64) NOT NULL DEFAULT '',
  `poc_1_phone_b` varchar(64) NOT NULL DEFAULT '',
  `poc_1_cell` varchar(64) NOT NULL DEFAULT '',
  `poc_1_screen` varchar(64) NOT NULL DEFAULT '',
  `poc_1_notes` text NOT NULL,
  `poc_2_name` varchar(128) NOT NULL DEFAULT '',
  `poc_2_email` varchar(128) NOT NULL DEFAULT '',
  `poc_2_phone_a` varchar(64) NOT NULL DEFAULT '',
  `poc_2_phone_b` varchar(64) NOT NULL DEFAULT '',
  `poc_2_cell` varchar(64) NOT NULL DEFAULT '',
  `poc_2_screen` varchar(64) NOT NULL DEFAULT '',
  `poc_2_notes` text NOT NULL,
  PRIMARY KEY (`hostid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `host_inventory`
--

LOCK TABLES `host_inventory` WRITE;
/*!40000 ALTER TABLE `host_inventory` DISABLE KEYS */;
/*!40000 ALTER TABLE `host_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `host_proxy`
--

DROP TABLE IF EXISTS `host_proxy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `host_proxy` (
  `hostproxyid` bigint unsigned NOT NULL,
  `hostid` bigint unsigned DEFAULT NULL,
  `host` varchar(128) NOT NULL DEFAULT '',
  `proxyid` bigint unsigned DEFAULT NULL,
  `revision` bigint unsigned NOT NULL DEFAULT '0',
  `tls_accept` int NOT NULL DEFAULT '1',
  `tls_issuer` varchar(1024) NOT NULL DEFAULT '',
  `tls_subject` varchar(1024) NOT NULL DEFAULT '',
  `tls_psk_identity` varchar(128) NOT NULL DEFAULT '',
  `tls_psk` varchar(512) NOT NULL DEFAULT '',
  PRIMARY KEY (`hostproxyid`),
  UNIQUE KEY `host_proxy_1` (`hostid`),
  KEY `host_proxy_2` (`proxyid`),
  KEY `host_proxy_3` (`revision`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `host_proxy`
--

LOCK TABLES `host_proxy` WRITE;
/*!40000 ALTER TABLE `host_proxy` DISABLE KEYS */;
/*!40000 ALTER TABLE `host_proxy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `host_rtdata`
--

DROP TABLE IF EXISTS `host_rtdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `host_rtdata` (
  `hostid` bigint unsigned NOT NULL,
  `active_available` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`hostid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `host_rtdata`
--

LOCK TABLES `host_rtdata` WRITE;
/*!40000 ALTER TABLE `host_rtdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `host_rtdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `host_tag`
--

DROP TABLE IF EXISTS `host_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `host_tag` (
  `hosttagid` bigint unsigned NOT NULL,
  `hostid` bigint unsigned NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  `automatic` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`hosttagid`),
  KEY `host_tag_1` (`hostid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `host_tag`
--

LOCK TABLES `host_tag` WRITE;
/*!40000 ALTER TABLE `host_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `host_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hostmacro`
--

DROP TABLE IF EXISTS `hostmacro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hostmacro` (
  `hostmacroid` bigint unsigned NOT NULL,
  `hostid` bigint unsigned NOT NULL,
  `macro` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(2048) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `automatic` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`hostmacroid`),
  UNIQUE KEY `hostmacro_1` (`hostid`,`macro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hostmacro`
--

LOCK TABLES `hostmacro` WRITE;
/*!40000 ALTER TABLE `hostmacro` DISABLE KEYS */;
/*!40000 ALTER TABLE `hostmacro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hostmacro_config`
--

DROP TABLE IF EXISTS `hostmacro_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hostmacro_config` (
  `hostmacroid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `priority` int NOT NULL DEFAULT '0',
  `section_name` varchar(255) NOT NULL DEFAULT '',
  `label` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `required` int NOT NULL DEFAULT '0',
  `regex` varchar(255) NOT NULL DEFAULT '',
  `options` text NOT NULL,
  PRIMARY KEY (`hostmacroid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hostmacro_config`
--

LOCK TABLES `hostmacro_config` WRITE;
/*!40000 ALTER TABLE `hostmacro_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `hostmacro_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hosts`
--

DROP TABLE IF EXISTS `hosts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hosts` (
  `hostid` bigint unsigned NOT NULL,
  `proxyid` bigint unsigned DEFAULT NULL,
  `host` varchar(128) NOT NULL DEFAULT '',
  `status` int NOT NULL DEFAULT '0',
  `ipmi_authtype` int NOT NULL DEFAULT '-1',
  `ipmi_privilege` int NOT NULL DEFAULT '2',
  `ipmi_username` varchar(16) NOT NULL DEFAULT '',
  `ipmi_password` varchar(20) NOT NULL DEFAULT '',
  `maintenanceid` bigint unsigned DEFAULT NULL,
  `maintenance_status` int NOT NULL DEFAULT '0',
  `maintenance_type` int NOT NULL DEFAULT '0',
  `maintenance_from` int NOT NULL DEFAULT '0',
  `name` varchar(128) NOT NULL DEFAULT '',
  `flags` int NOT NULL DEFAULT '0',
  `templateid` bigint unsigned DEFAULT NULL,
  `description` text NOT NULL,
  `tls_connect` int NOT NULL DEFAULT '1',
  `tls_accept` int NOT NULL DEFAULT '1',
  `tls_issuer` varchar(1024) NOT NULL DEFAULT '',
  `tls_subject` varchar(1024) NOT NULL DEFAULT '',
  `tls_psk_identity` varchar(128) NOT NULL DEFAULT '',
  `tls_psk` varchar(512) NOT NULL DEFAULT '',
  `discover` int NOT NULL DEFAULT '0',
  `custom_interfaces` int NOT NULL DEFAULT '0',
  `uuid` varchar(32) NOT NULL DEFAULT '',
  `name_upper` varchar(128) NOT NULL DEFAULT '',
  `vendor_name` varchar(64) NOT NULL DEFAULT '',
  `vendor_version` varchar(32) NOT NULL DEFAULT '',
  `proxy_groupid` bigint unsigned DEFAULT NULL,
  `monitored_by` int NOT NULL DEFAULT '0',
  `wizard_ready` int NOT NULL DEFAULT '0',
  `readme` text NOT NULL,
  PRIMARY KEY (`hostid`),
  KEY `hosts_1` (`host`),
  KEY `hosts_2` (`status`),
  KEY `hosts_3` (`proxyid`),
  KEY `hosts_4` (`name`),
  KEY `hosts_5` (`maintenanceid`),
  KEY `hosts_6` (`name_upper`),
  KEY `hosts_7` (`templateid`),
  KEY `hosts_8` (`proxy_groupid`),
  KEY `hosts_9` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hosts`
--

LOCK TABLES `hosts` WRITE;
/*!40000 ALTER TABLE `hosts` DISABLE KEYS */;
/*!40000 ALTER TABLE `hosts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hosts_groups`
--

DROP TABLE IF EXISTS `hosts_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hosts_groups` (
  `hostgroupid` bigint unsigned NOT NULL,
  `hostid` bigint unsigned NOT NULL,
  `groupid` bigint unsigned NOT NULL,
  PRIMARY KEY (`hostgroupid`),
  UNIQUE KEY `hosts_groups_1` (`hostid`,`groupid`),
  KEY `hosts_groups_2` (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hosts_groups`
--

LOCK TABLES `hosts_groups` WRITE;
/*!40000 ALTER TABLE `hosts_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `hosts_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hosts_templates`
--

DROP TABLE IF EXISTS `hosts_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hosts_templates` (
  `hosttemplateid` bigint unsigned NOT NULL,
  `hostid` bigint unsigned NOT NULL,
  `templateid` bigint unsigned NOT NULL,
  `link_type` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`hosttemplateid`),
  UNIQUE KEY `hosts_templates_1` (`hostid`,`templateid`),
  KEY `hosts_templates_2` (`templateid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hosts_templates`
--

LOCK TABLES `hosts_templates` WRITE;
/*!40000 ALTER TABLE `hosts_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `hosts_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `housekeeper`
--

DROP TABLE IF EXISTS `housekeeper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `housekeeper` (
  `housekeeperid` bigint unsigned NOT NULL,
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `field` varchar(64) NOT NULL DEFAULT '',
  `value` bigint unsigned NOT NULL,
  PRIMARY KEY (`housekeeperid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `housekeeper`
--

LOCK TABLES `housekeeper` WRITE;
/*!40000 ALTER TABLE `housekeeper` DISABLE KEYS */;
/*!40000 ALTER TABLE `housekeeper` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hstgrp`
--

DROP TABLE IF EXISTS `hstgrp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hstgrp` (
  `groupid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `flags` int NOT NULL DEFAULT '0',
  `uuid` varchar(32) NOT NULL DEFAULT '',
  `type` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`groupid`),
  UNIQUE KEY `hstgrp_1` (`type`,`name`),
  KEY `hstgrp_2` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hstgrp`
--

LOCK TABLES `hstgrp` WRITE;
/*!40000 ALTER TABLE `hstgrp` DISABLE KEYS */;
/*!40000 ALTER TABLE `hstgrp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `httpstep`
--

DROP TABLE IF EXISTS `httpstep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `httpstep` (
  `httpstepid` bigint unsigned NOT NULL,
  `httptestid` bigint unsigned NOT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `no` int NOT NULL DEFAULT '0',
  `url` varchar(2048) NOT NULL DEFAULT '',
  `timeout` varchar(255) NOT NULL DEFAULT '15s',
  `posts` text NOT NULL,
  `required` varchar(255) NOT NULL DEFAULT '',
  `status_codes` varchar(255) NOT NULL DEFAULT '',
  `follow_redirects` int NOT NULL DEFAULT '1',
  `retrieve_mode` int NOT NULL DEFAULT '0',
  `post_type` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`httpstepid`),
  KEY `httpstep_1` (`httptestid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `httpstep`
--

LOCK TABLES `httpstep` WRITE;
/*!40000 ALTER TABLE `httpstep` DISABLE KEYS */;
/*!40000 ALTER TABLE `httpstep` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `httpstep_field`
--

DROP TABLE IF EXISTS `httpstep_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `httpstep_field` (
  `httpstep_fieldid` bigint unsigned NOT NULL,
  `httpstepid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`httpstep_fieldid`),
  KEY `httpstep_field_1` (`httpstepid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `httpstep_field`
--

LOCK TABLES `httpstep_field` WRITE;
/*!40000 ALTER TABLE `httpstep_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `httpstep_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `httpstepitem`
--

DROP TABLE IF EXISTS `httpstepitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `httpstepitem` (
  `httpstepitemid` bigint unsigned NOT NULL,
  `httpstepid` bigint unsigned NOT NULL,
  `itemid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`httpstepitemid`),
  UNIQUE KEY `httpstepitem_1` (`httpstepid`,`itemid`),
  KEY `httpstepitem_2` (`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `httpstepitem`
--

LOCK TABLES `httpstepitem` WRITE;
/*!40000 ALTER TABLE `httpstepitem` DISABLE KEYS */;
/*!40000 ALTER TABLE `httpstepitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `httptest`
--

DROP TABLE IF EXISTS `httptest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `httptest` (
  `httptestid` bigint unsigned NOT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `delay` varchar(255) NOT NULL DEFAULT '1m',
  `status` int NOT NULL DEFAULT '0',
  `agent` varchar(255) NOT NULL DEFAULT 'Zabbix',
  `authentication` int NOT NULL DEFAULT '0',
  `http_user` varchar(255) NOT NULL DEFAULT '',
  `http_password` varchar(255) NOT NULL DEFAULT '',
  `hostid` bigint unsigned NOT NULL,
  `templateid` bigint unsigned DEFAULT NULL,
  `http_proxy` varchar(255) NOT NULL DEFAULT '',
  `retries` int NOT NULL DEFAULT '1',
  `ssl_cert_file` varchar(255) NOT NULL DEFAULT '',
  `ssl_key_file` varchar(255) NOT NULL DEFAULT '',
  `ssl_key_password` varchar(64) NOT NULL DEFAULT '',
  `verify_peer` int NOT NULL DEFAULT '0',
  `verify_host` int NOT NULL DEFAULT '0',
  `uuid` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`httptestid`),
  UNIQUE KEY `httptest_2` (`hostid`,`name`),
  KEY `httptest_3` (`status`),
  KEY `httptest_4` (`templateid`),
  KEY `httptest_5` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `httptest`
--

LOCK TABLES `httptest` WRITE;
/*!40000 ALTER TABLE `httptest` DISABLE KEYS */;
/*!40000 ALTER TABLE `httptest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `httptest_field`
--

DROP TABLE IF EXISTS `httptest_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `httptest_field` (
  `httptest_fieldid` bigint unsigned NOT NULL,
  `httptestid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`httptest_fieldid`),
  KEY `httptest_field_1` (`httptestid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `httptest_field`
--

LOCK TABLES `httptest_field` WRITE;
/*!40000 ALTER TABLE `httptest_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `httptest_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `httptest_tag`
--

DROP TABLE IF EXISTS `httptest_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `httptest_tag` (
  `httptesttagid` bigint unsigned NOT NULL,
  `httptestid` bigint unsigned NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`httptesttagid`),
  KEY `httptest_tag_1` (`httptestid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `httptest_tag`
--

LOCK TABLES `httptest_tag` WRITE;
/*!40000 ALTER TABLE `httptest_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `httptest_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `httptestitem`
--

DROP TABLE IF EXISTS `httptestitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `httptestitem` (
  `httptestitemid` bigint unsigned NOT NULL,
  `httptestid` bigint unsigned NOT NULL,
  `itemid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`httptestitemid`),
  UNIQUE KEY `httptestitem_1` (`httptestid`,`itemid`),
  KEY `httptestitem_2` (`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `httptestitem`
--

LOCK TABLES `httptestitem` WRITE;
/*!40000 ALTER TABLE `httptestitem` DISABLE KEYS */;
/*!40000 ALTER TABLE `httptestitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `icon_map`
--

DROP TABLE IF EXISTS `icon_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `icon_map` (
  `iconmapid` bigint unsigned NOT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `default_iconid` bigint unsigned NOT NULL,
  PRIMARY KEY (`iconmapid`),
  UNIQUE KEY `icon_map_1` (`name`),
  KEY `icon_map_2` (`default_iconid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `icon_map`
--

LOCK TABLES `icon_map` WRITE;
/*!40000 ALTER TABLE `icon_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `icon_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `icon_mapping`
--

DROP TABLE IF EXISTS `icon_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `icon_mapping` (
  `iconmappingid` bigint unsigned NOT NULL,
  `iconmapid` bigint unsigned NOT NULL,
  `iconid` bigint unsigned NOT NULL,
  `inventory_link` int NOT NULL DEFAULT '0',
  `expression` varchar(64) NOT NULL DEFAULT '',
  `sortorder` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`iconmappingid`),
  KEY `icon_mapping_1` (`iconmapid`),
  KEY `icon_mapping_2` (`iconid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `icon_mapping`
--

LOCK TABLES `icon_mapping` WRITE;
/*!40000 ALTER TABLE `icon_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `icon_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ids`
--

DROP TABLE IF EXISTS `ids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ids` (
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `field_name` varchar(64) NOT NULL DEFAULT '',
  `nextid` bigint unsigned NOT NULL,
  PRIMARY KEY (`table_name`,`field_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ids`
--

LOCK TABLES `ids` WRITE;
/*!40000 ALTER TABLE `ids` DISABLE KEYS */;
/*!40000 ALTER TABLE `ids` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `images` (
  `imageid` bigint unsigned NOT NULL,
  `imagetype` int NOT NULL DEFAULT '0',
  `name` varchar(64) NOT NULL DEFAULT '0',
  `image` longblob NOT NULL,
  PRIMARY KEY (`imageid`),
  UNIQUE KEY `images_1` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images`
--

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interface`
--

DROP TABLE IF EXISTS `interface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interface` (
  `interfaceid` bigint unsigned NOT NULL,
  `hostid` bigint unsigned NOT NULL,
  `main` int NOT NULL DEFAULT '0',
  `type` int NOT NULL DEFAULT '1',
  `useip` int NOT NULL DEFAULT '1',
  `ip` varchar(64) NOT NULL DEFAULT '127.0.0.1',
  `dns` varchar(255) NOT NULL DEFAULT '',
  `port` varchar(64) NOT NULL DEFAULT '10050',
  `available` int NOT NULL DEFAULT '0',
  `error` varchar(2048) NOT NULL DEFAULT '',
  `errors_from` int NOT NULL DEFAULT '0',
  `disable_until` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`interfaceid`),
  KEY `interface_1` (`hostid`,`type`),
  KEY `interface_2` (`ip`,`dns`),
  KEY `interface_3` (`available`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interface`
--

LOCK TABLES `interface` WRITE;
/*!40000 ALTER TABLE `interface` DISABLE KEYS */;
/*!40000 ALTER TABLE `interface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interface_discovery`
--

DROP TABLE IF EXISTS `interface_discovery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interface_discovery` (
  `interfaceid` bigint unsigned NOT NULL,
  `parent_interfaceid` bigint unsigned NOT NULL,
  PRIMARY KEY (`interfaceid`),
  KEY `interface_discovery_1` (`parent_interfaceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interface_discovery`
--

LOCK TABLES `interface_discovery` WRITE;
/*!40000 ALTER TABLE `interface_discovery` DISABLE KEYS */;
/*!40000 ALTER TABLE `interface_discovery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `interface_snmp`
--

DROP TABLE IF EXISTS `interface_snmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `interface_snmp` (
  `interfaceid` bigint unsigned NOT NULL,
  `version` int NOT NULL DEFAULT '2',
  `bulk` int NOT NULL DEFAULT '1',
  `community` varchar(64) NOT NULL DEFAULT '',
  `securityname` varchar(64) NOT NULL DEFAULT '',
  `securitylevel` int NOT NULL DEFAULT '0',
  `authpassphrase` varchar(64) NOT NULL DEFAULT '',
  `privpassphrase` varchar(64) NOT NULL DEFAULT '',
  `authprotocol` int NOT NULL DEFAULT '0',
  `privprotocol` int NOT NULL DEFAULT '0',
  `contextname` varchar(255) NOT NULL DEFAULT '',
  `max_repetitions` int NOT NULL DEFAULT '10',
  PRIMARY KEY (`interfaceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `interface_snmp`
--

LOCK TABLES `interface_snmp` WRITE;
/*!40000 ALTER TABLE `interface_snmp` DISABLE KEYS */;
/*!40000 ALTER TABLE `interface_snmp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_condition`
--

DROP TABLE IF EXISTS `item_condition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_condition` (
  `item_conditionid` bigint unsigned NOT NULL,
  `itemid` bigint unsigned NOT NULL,
  `operator` int NOT NULL DEFAULT '8',
  `macro` varchar(64) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`item_conditionid`),
  KEY `item_condition_1` (`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_condition`
--

LOCK TABLES `item_condition` WRITE;
/*!40000 ALTER TABLE `item_condition` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_condition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_discovery`
--

DROP TABLE IF EXISTS `item_discovery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_discovery` (
  `itemdiscoveryid` bigint unsigned NOT NULL,
  `itemid` bigint unsigned NOT NULL,
  `parent_itemid` bigint unsigned DEFAULT NULL,
  `key_` varchar(2048) NOT NULL DEFAULT '',
  `lastcheck` int NOT NULL DEFAULT '0',
  `ts_delete` int NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '0',
  `disable_source` int NOT NULL DEFAULT '0',
  `ts_disable` int NOT NULL DEFAULT '0',
  `lldruleid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`itemdiscoveryid`),
  UNIQUE KEY `item_discovery_1` (`itemid`,`parent_itemid`),
  KEY `item_discovery_2` (`parent_itemid`),
  KEY `item_discovery_3` (`lldruleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_discovery`
--

LOCK TABLES `item_discovery` WRITE;
/*!40000 ALTER TABLE `item_discovery` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_discovery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_parameter`
--

DROP TABLE IF EXISTS `item_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_parameter` (
  `item_parameterid` bigint unsigned NOT NULL,
  `itemid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(2048) NOT NULL DEFAULT '',
  PRIMARY KEY (`item_parameterid`),
  KEY `item_parameter_1` (`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_parameter`
--

LOCK TABLES `item_parameter` WRITE;
/*!40000 ALTER TABLE `item_parameter` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_preproc`
--

DROP TABLE IF EXISTS `item_preproc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_preproc` (
  `item_preprocid` bigint unsigned NOT NULL,
  `itemid` bigint unsigned NOT NULL,
  `step` int NOT NULL DEFAULT '0',
  `type` int NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `error_handler` int NOT NULL DEFAULT '0',
  `error_handler_params` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`item_preprocid`),
  KEY `item_preproc_1` (`itemid`,`step`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_preproc`
--

LOCK TABLES `item_preproc` WRITE;
/*!40000 ALTER TABLE `item_preproc` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_preproc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_rtdata`
--

DROP TABLE IF EXISTS `item_rtdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_rtdata` (
  `itemid` bigint unsigned NOT NULL,
  `lastlogsize` bigint unsigned NOT NULL DEFAULT '0',
  `state` int NOT NULL DEFAULT '0',
  `mtime` int NOT NULL DEFAULT '0',
  `error` varchar(2048) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_rtdata`
--

LOCK TABLES `item_rtdata` WRITE;
/*!40000 ALTER TABLE `item_rtdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_rtdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_rtname`
--

DROP TABLE IF EXISTS `item_rtname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_rtname` (
  `itemid` bigint unsigned NOT NULL,
  `name_resolved` varchar(2048) NOT NULL DEFAULT '',
  `name_resolved_upper` varchar(2048) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_rtname`
--

LOCK TABLES `item_rtname` WRITE;
/*!40000 ALTER TABLE `item_rtname` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_rtname` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_tag`
--

DROP TABLE IF EXISTS `item_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_tag` (
  `itemtagid` bigint unsigned NOT NULL,
  `itemid` bigint unsigned NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemtagid`),
  KEY `item_tag_1` (`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_tag`
--

LOCK TABLES `item_tag` WRITE;
/*!40000 ALTER TABLE `item_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `itemid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `snmp_oid` varchar(512) NOT NULL DEFAULT '',
  `hostid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `key_` varchar(2048) NOT NULL DEFAULT '',
  `delay` varchar(1024) NOT NULL DEFAULT '0',
  `history` varchar(255) NOT NULL DEFAULT '31d',
  `trends` varchar(255) NOT NULL DEFAULT '365d',
  `status` int NOT NULL DEFAULT '0',
  `value_type` int NOT NULL DEFAULT '0',
  `trapper_hosts` varchar(255) NOT NULL DEFAULT '',
  `units` varchar(255) NOT NULL DEFAULT '',
  `formula` varchar(255) NOT NULL DEFAULT '',
  `logtimefmt` varchar(64) NOT NULL DEFAULT '',
  `templateid` bigint unsigned DEFAULT NULL,
  `valuemapid` bigint unsigned DEFAULT NULL,
  `params` text NOT NULL,
  `ipmi_sensor` varchar(128) NOT NULL DEFAULT '',
  `authtype` int NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `publickey` varchar(64) NOT NULL DEFAULT '',
  `privatekey` varchar(64) NOT NULL DEFAULT '',
  `flags` int NOT NULL DEFAULT '0',
  `interfaceid` bigint unsigned DEFAULT NULL,
  `description` text NOT NULL,
  `inventory_link` int NOT NULL DEFAULT '0',
  `lifetime` varchar(255) NOT NULL DEFAULT '7d',
  `evaltype` int NOT NULL DEFAULT '0',
  `jmx_endpoint` varchar(255) NOT NULL DEFAULT '',
  `master_itemid` bigint unsigned DEFAULT NULL,
  `timeout` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(2048) NOT NULL DEFAULT '',
  `query_fields` text NOT NULL,
  `posts` text NOT NULL,
  `status_codes` varchar(255) NOT NULL DEFAULT '200',
  `follow_redirects` int NOT NULL DEFAULT '1',
  `post_type` int NOT NULL DEFAULT '0',
  `http_proxy` varchar(255) NOT NULL DEFAULT '',
  `headers` text NOT NULL,
  `retrieve_mode` int NOT NULL DEFAULT '0',
  `request_method` int NOT NULL DEFAULT '0',
  `output_format` int NOT NULL DEFAULT '0',
  `ssl_cert_file` varchar(255) NOT NULL DEFAULT '',
  `ssl_key_file` varchar(255) NOT NULL DEFAULT '',
  `ssl_key_password` varchar(64) NOT NULL DEFAULT '',
  `verify_peer` int NOT NULL DEFAULT '0',
  `verify_host` int NOT NULL DEFAULT '0',
  `allow_traps` int NOT NULL DEFAULT '0',
  `discover` int NOT NULL DEFAULT '0',
  `uuid` varchar(32) NOT NULL DEFAULT '',
  `lifetime_type` int NOT NULL DEFAULT '0',
  `enabled_lifetime_type` int NOT NULL DEFAULT '2',
  `enabled_lifetime` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `items_1` (`hostid`,`key_`(764)),
  KEY `items_3` (`status`),
  KEY `items_4` (`templateid`),
  KEY `items_5` (`valuemapid`),
  KEY `items_6` (`interfaceid`),
  KEY `items_7` (`master_itemid`),
  KEY `items_8` (`key_`(768)),
  KEY `items_10` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lld_macro_export`
--

DROP TABLE IF EXISTS `lld_macro_export`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_macro_export` (
  `lld_macro_exportid` bigint unsigned NOT NULL,
  `itemid` bigint unsigned NOT NULL,
  `lld_macro` varchar(255) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`lld_macro_exportid`),
  KEY `lld_macro_export_1` (`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_macro_export`
--

LOCK TABLES `lld_macro_export` WRITE;
/*!40000 ALTER TABLE `lld_macro_export` DISABLE KEYS */;
/*!40000 ALTER TABLE `lld_macro_export` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lld_macro_path`
--

DROP TABLE IF EXISTS `lld_macro_path`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_macro_path` (
  `lld_macro_pathid` bigint unsigned NOT NULL,
  `itemid` bigint unsigned NOT NULL,
  `lld_macro` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`lld_macro_pathid`),
  UNIQUE KEY `lld_macro_path_1` (`itemid`,`lld_macro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_macro_path`
--

LOCK TABLES `lld_macro_path` WRITE;
/*!40000 ALTER TABLE `lld_macro_path` DISABLE KEYS */;
/*!40000 ALTER TABLE `lld_macro_path` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lld_override`
--

DROP TABLE IF EXISTS `lld_override`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_override` (
  `lld_overrideid` bigint unsigned NOT NULL,
  `itemid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `step` int NOT NULL DEFAULT '0',
  `evaltype` int NOT NULL DEFAULT '0',
  `formula` varchar(255) NOT NULL DEFAULT '',
  `stop` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`lld_overrideid`),
  UNIQUE KEY `lld_override_1` (`itemid`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_override`
--

LOCK TABLES `lld_override` WRITE;
/*!40000 ALTER TABLE `lld_override` DISABLE KEYS */;
/*!40000 ALTER TABLE `lld_override` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lld_override_condition`
--

DROP TABLE IF EXISTS `lld_override_condition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_override_condition` (
  `lld_override_conditionid` bigint unsigned NOT NULL,
  `lld_overrideid` bigint unsigned NOT NULL,
  `operator` int NOT NULL DEFAULT '8',
  `macro` varchar(64) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`lld_override_conditionid`),
  KEY `lld_override_condition_1` (`lld_overrideid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_override_condition`
--

LOCK TABLES `lld_override_condition` WRITE;
/*!40000 ALTER TABLE `lld_override_condition` DISABLE KEYS */;
/*!40000 ALTER TABLE `lld_override_condition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lld_override_opdiscover`
--

DROP TABLE IF EXISTS `lld_override_opdiscover`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_override_opdiscover` (
  `lld_override_operationid` bigint unsigned NOT NULL,
  `discover` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`lld_override_operationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_override_opdiscover`
--

LOCK TABLES `lld_override_opdiscover` WRITE;
/*!40000 ALTER TABLE `lld_override_opdiscover` DISABLE KEYS */;
/*!40000 ALTER TABLE `lld_override_opdiscover` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lld_override_operation`
--

DROP TABLE IF EXISTS `lld_override_operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_override_operation` (
  `lld_override_operationid` bigint unsigned NOT NULL,
  `lld_overrideid` bigint unsigned NOT NULL,
  `operationobject` int NOT NULL DEFAULT '0',
  `operator` int NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`lld_override_operationid`),
  KEY `lld_override_operation_1` (`lld_overrideid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_override_operation`
--

LOCK TABLES `lld_override_operation` WRITE;
/*!40000 ALTER TABLE `lld_override_operation` DISABLE KEYS */;
/*!40000 ALTER TABLE `lld_override_operation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lld_override_ophistory`
--

DROP TABLE IF EXISTS `lld_override_ophistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_override_ophistory` (
  `lld_override_operationid` bigint unsigned NOT NULL,
  `history` varchar(255) NOT NULL DEFAULT '31d',
  PRIMARY KEY (`lld_override_operationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_override_ophistory`
--

LOCK TABLES `lld_override_ophistory` WRITE;
/*!40000 ALTER TABLE `lld_override_ophistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `lld_override_ophistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lld_override_opinventory`
--

DROP TABLE IF EXISTS `lld_override_opinventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_override_opinventory` (
  `lld_override_operationid` bigint unsigned NOT NULL,
  `inventory_mode` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`lld_override_operationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_override_opinventory`
--

LOCK TABLES `lld_override_opinventory` WRITE;
/*!40000 ALTER TABLE `lld_override_opinventory` DISABLE KEYS */;
/*!40000 ALTER TABLE `lld_override_opinventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lld_override_opperiod`
--

DROP TABLE IF EXISTS `lld_override_opperiod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_override_opperiod` (
  `lld_override_operationid` bigint unsigned NOT NULL,
  `delay` varchar(1024) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lld_override_operationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_override_opperiod`
--

LOCK TABLES `lld_override_opperiod` WRITE;
/*!40000 ALTER TABLE `lld_override_opperiod` DISABLE KEYS */;
/*!40000 ALTER TABLE `lld_override_opperiod` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lld_override_opseverity`
--

DROP TABLE IF EXISTS `lld_override_opseverity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_override_opseverity` (
  `lld_override_operationid` bigint unsigned NOT NULL,
  `severity` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`lld_override_operationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_override_opseverity`
--

LOCK TABLES `lld_override_opseverity` WRITE;
/*!40000 ALTER TABLE `lld_override_opseverity` DISABLE KEYS */;
/*!40000 ALTER TABLE `lld_override_opseverity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lld_override_opstatus`
--

DROP TABLE IF EXISTS `lld_override_opstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_override_opstatus` (
  `lld_override_operationid` bigint unsigned NOT NULL,
  `status` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`lld_override_operationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_override_opstatus`
--

LOCK TABLES `lld_override_opstatus` WRITE;
/*!40000 ALTER TABLE `lld_override_opstatus` DISABLE KEYS */;
/*!40000 ALTER TABLE `lld_override_opstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lld_override_optag`
--

DROP TABLE IF EXISTS `lld_override_optag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_override_optag` (
  `lld_override_optagid` bigint unsigned NOT NULL,
  `lld_override_operationid` bigint unsigned NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`lld_override_optagid`),
  KEY `lld_override_optag_1` (`lld_override_operationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_override_optag`
--

LOCK TABLES `lld_override_optag` WRITE;
/*!40000 ALTER TABLE `lld_override_optag` DISABLE KEYS */;
/*!40000 ALTER TABLE `lld_override_optag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lld_override_optemplate`
--

DROP TABLE IF EXISTS `lld_override_optemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_override_optemplate` (
  `lld_override_optemplateid` bigint unsigned NOT NULL,
  `lld_override_operationid` bigint unsigned NOT NULL,
  `templateid` bigint unsigned NOT NULL,
  PRIMARY KEY (`lld_override_optemplateid`),
  UNIQUE KEY `lld_override_optemplate_1` (`lld_override_operationid`,`templateid`),
  KEY `lld_override_optemplate_2` (`templateid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_override_optemplate`
--

LOCK TABLES `lld_override_optemplate` WRITE;
/*!40000 ALTER TABLE `lld_override_optemplate` DISABLE KEYS */;
/*!40000 ALTER TABLE `lld_override_optemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lld_override_optrends`
--

DROP TABLE IF EXISTS `lld_override_optrends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_override_optrends` (
  `lld_override_operationid` bigint unsigned NOT NULL,
  `trends` varchar(255) NOT NULL DEFAULT '365d',
  PRIMARY KEY (`lld_override_operationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_override_optrends`
--

LOCK TABLES `lld_override_optrends` WRITE;
/*!40000 ALTER TABLE `lld_override_optrends` DISABLE KEYS */;
/*!40000 ALTER TABLE `lld_override_optrends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maintenance_tag`
--

DROP TABLE IF EXISTS `maintenance_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `maintenance_tag` (
  `maintenancetagid` bigint unsigned NOT NULL,
  `maintenanceid` bigint unsigned NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `operator` int NOT NULL DEFAULT '2',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`maintenancetagid`),
  KEY `maintenance_tag_1` (`maintenanceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenance_tag`
--

LOCK TABLES `maintenance_tag` WRITE;
/*!40000 ALTER TABLE `maintenance_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `maintenance_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maintenances`
--

DROP TABLE IF EXISTS `maintenances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `maintenances` (
  `maintenanceid` bigint unsigned NOT NULL,
  `name` varchar(128) NOT NULL DEFAULT '',
  `maintenance_type` int NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `active_since` int NOT NULL DEFAULT '0',
  `active_till` int NOT NULL DEFAULT '0',
  `tags_evaltype` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`maintenanceid`),
  UNIQUE KEY `maintenances_2` (`name`),
  KEY `maintenances_1` (`active_since`,`active_till`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenances`
--

LOCK TABLES `maintenances` WRITE;
/*!40000 ALTER TABLE `maintenances` DISABLE KEYS */;
/*!40000 ALTER TABLE `maintenances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maintenances_groups`
--

DROP TABLE IF EXISTS `maintenances_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `maintenances_groups` (
  `maintenance_groupid` bigint unsigned NOT NULL,
  `maintenanceid` bigint unsigned NOT NULL,
  `groupid` bigint unsigned NOT NULL,
  PRIMARY KEY (`maintenance_groupid`),
  UNIQUE KEY `maintenances_groups_1` (`maintenanceid`,`groupid`),
  KEY `maintenances_groups_2` (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenances_groups`
--

LOCK TABLES `maintenances_groups` WRITE;
/*!40000 ALTER TABLE `maintenances_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `maintenances_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maintenances_hosts`
--

DROP TABLE IF EXISTS `maintenances_hosts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `maintenances_hosts` (
  `maintenance_hostid` bigint unsigned NOT NULL,
  `maintenanceid` bigint unsigned NOT NULL,
  `hostid` bigint unsigned NOT NULL,
  PRIMARY KEY (`maintenance_hostid`),
  UNIQUE KEY `maintenances_hosts_1` (`maintenanceid`,`hostid`),
  KEY `maintenances_hosts_2` (`hostid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenances_hosts`
--

LOCK TABLES `maintenances_hosts` WRITE;
/*!40000 ALTER TABLE `maintenances_hosts` DISABLE KEYS */;
/*!40000 ALTER TABLE `maintenances_hosts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maintenances_windows`
--

DROP TABLE IF EXISTS `maintenances_windows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `maintenances_windows` (
  `maintenance_timeperiodid` bigint unsigned NOT NULL,
  `maintenanceid` bigint unsigned NOT NULL,
  `timeperiodid` bigint unsigned NOT NULL,
  PRIMARY KEY (`maintenance_timeperiodid`),
  UNIQUE KEY `maintenances_windows_1` (`maintenanceid`,`timeperiodid`),
  KEY `maintenances_windows_2` (`timeperiodid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenances_windows`
--

LOCK TABLES `maintenances_windows` WRITE;
/*!40000 ALTER TABLE `maintenances_windows` DISABLE KEYS */;
/*!40000 ALTER TABLE `maintenances_windows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media` (
  `mediaid` bigint unsigned NOT NULL,
  `userid` bigint unsigned NOT NULL,
  `mediatypeid` bigint unsigned NOT NULL,
  `sendto` varchar(1024) NOT NULL DEFAULT '',
  `active` int NOT NULL DEFAULT '0',
  `severity` int NOT NULL DEFAULT '63',
  `period` varchar(1024) NOT NULL DEFAULT '1-7,00:00-24:00',
  `userdirectory_mediaid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`mediaid`),
  KEY `media_1` (`userid`),
  KEY `media_2` (`mediatypeid`),
  KEY `media_3` (`userdirectory_mediaid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_type`
--

DROP TABLE IF EXISTS `media_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_type` (
  `mediatypeid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `smtp_server` varchar(255) NOT NULL DEFAULT '',
  `smtp_helo` varchar(255) NOT NULL DEFAULT '',
  `smtp_email` varchar(255) NOT NULL DEFAULT '',
  `exec_path` varchar(255) NOT NULL DEFAULT '',
  `gsm_modem` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `passwd` varchar(255) NOT NULL DEFAULT '',
  `status` int NOT NULL DEFAULT '1',
  `smtp_port` int NOT NULL DEFAULT '25',
  `smtp_security` int NOT NULL DEFAULT '0',
  `smtp_verify_peer` int NOT NULL DEFAULT '0',
  `smtp_verify_host` int NOT NULL DEFAULT '0',
  `smtp_authentication` int NOT NULL DEFAULT '0',
  `maxsessions` int NOT NULL DEFAULT '1',
  `maxattempts` int NOT NULL DEFAULT '3',
  `attempt_interval` varchar(32) NOT NULL DEFAULT '10s',
  `message_format` int NOT NULL DEFAULT '1',
  `script` text NOT NULL,
  `timeout` varchar(32) NOT NULL DEFAULT '30s',
  `process_tags` int NOT NULL DEFAULT '0',
  `show_event_menu` int NOT NULL DEFAULT '0',
  `event_menu_url` varchar(2048) NOT NULL DEFAULT '',
  `event_menu_name` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `provider` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`mediatypeid`),
  UNIQUE KEY `media_type_1` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_type`
--

LOCK TABLES `media_type` WRITE;
/*!40000 ALTER TABLE `media_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_type_message`
--

DROP TABLE IF EXISTS `media_type_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_type_message` (
  `mediatype_messageid` bigint unsigned NOT NULL,
  `mediatypeid` bigint unsigned NOT NULL,
  `eventsource` int NOT NULL,
  `recovery` int NOT NULL,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  PRIMARY KEY (`mediatype_messageid`),
  UNIQUE KEY `media_type_message_1` (`mediatypeid`,`eventsource`,`recovery`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_type_message`
--

LOCK TABLES `media_type_message` WRITE;
/*!40000 ALTER TABLE `media_type_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_type_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_type_oauth`
--

DROP TABLE IF EXISTS `media_type_oauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_type_oauth` (
  `mediatypeid` bigint unsigned NOT NULL,
  `redirection_url` varchar(2048) NOT NULL DEFAULT '',
  `client_id` varchar(255) NOT NULL DEFAULT '',
  `client_secret` varchar(255) NOT NULL DEFAULT '',
  `authorization_url` varchar(2048) NOT NULL DEFAULT '',
  `tokens_status` int NOT NULL DEFAULT '0',
  `access_token` text NOT NULL,
  `access_token_updated` int NOT NULL DEFAULT '0',
  `access_expires_in` int NOT NULL DEFAULT '0',
  `refresh_token` text NOT NULL,
  `token_url` varchar(2048) NOT NULL DEFAULT '',
  PRIMARY KEY (`mediatypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_type_oauth`
--

LOCK TABLES `media_type_oauth` WRITE;
/*!40000 ALTER TABLE `media_type_oauth` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_type_oauth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media_type_param`
--

DROP TABLE IF EXISTS `media_type_param`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_type_param` (
  `mediatype_paramid` bigint unsigned NOT NULL,
  `mediatypeid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(2048) NOT NULL DEFAULT '',
  `sortorder` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`mediatype_paramid`),
  KEY `media_type_param_1` (`mediatypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_type_param`
--

LOCK TABLES `media_type_param` WRITE;
/*!40000 ALTER TABLE `media_type_param` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_type_param` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mfa`
--

DROP TABLE IF EXISTS `mfa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mfa` (
  `mfaid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `name` varchar(128) NOT NULL DEFAULT '',
  `hash_function` int DEFAULT '1',
  `code_length` int DEFAULT '6',
  `api_hostname` varchar(1024) DEFAULT '',
  `clientid` varchar(32) DEFAULT '',
  `client_secret` varchar(64) DEFAULT '',
  PRIMARY KEY (`mfaid`),
  UNIQUE KEY `mfa_1` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mfa`
--

LOCK TABLES `mfa` WRITE;
/*!40000 ALTER TABLE `mfa` DISABLE KEYS */;
/*!40000 ALTER TABLE `mfa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mfa_totp_secret`
--

DROP TABLE IF EXISTS `mfa_totp_secret`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mfa_totp_secret` (
  `mfa_totp_secretid` bigint unsigned NOT NULL,
  `mfaid` bigint unsigned NOT NULL,
  `userid` bigint unsigned NOT NULL,
  `totp_secret` varchar(32) DEFAULT '',
  `status` int NOT NULL DEFAULT '0',
  `used_codes` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`mfa_totp_secretid`),
  KEY `mfa_totp_secret_1` (`mfaid`),
  KEY `mfa_totp_secret_2` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mfa_totp_secret`
--

LOCK TABLES `mfa_totp_secret` WRITE;
/*!40000 ALTER TABLE `mfa_totp_secret` DISABLE KEYS */;
/*!40000 ALTER TABLE `mfa_totp_secret` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `module`
--

DROP TABLE IF EXISTS `module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `module` (
  `moduleid` bigint unsigned NOT NULL,
  `id` varchar(255) NOT NULL DEFAULT '',
  `relative_path` varchar(255) NOT NULL DEFAULT '',
  `status` int NOT NULL DEFAULT '0',
  `config` text NOT NULL,
  PRIMARY KEY (`moduleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module`
--

LOCK TABLES `module` WRITE;
/*!40000 ALTER TABLE `module` DISABLE KEYS */;
/*!40000 ALTER TABLE `module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opcommand`
--

DROP TABLE IF EXISTS `opcommand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opcommand` (
  `operationid` bigint unsigned NOT NULL,
  `scriptid` bigint unsigned NOT NULL,
  PRIMARY KEY (`operationid`),
  KEY `opcommand_1` (`scriptid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opcommand`
--

LOCK TABLES `opcommand` WRITE;
/*!40000 ALTER TABLE `opcommand` DISABLE KEYS */;
/*!40000 ALTER TABLE `opcommand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opcommand_grp`
--

DROP TABLE IF EXISTS `opcommand_grp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opcommand_grp` (
  `opcommand_grpid` bigint unsigned NOT NULL,
  `operationid` bigint unsigned NOT NULL,
  `groupid` bigint unsigned NOT NULL,
  PRIMARY KEY (`opcommand_grpid`),
  KEY `opcommand_grp_1` (`operationid`),
  KEY `opcommand_grp_2` (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opcommand_grp`
--

LOCK TABLES `opcommand_grp` WRITE;
/*!40000 ALTER TABLE `opcommand_grp` DISABLE KEYS */;
/*!40000 ALTER TABLE `opcommand_grp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opcommand_hst`
--

DROP TABLE IF EXISTS `opcommand_hst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opcommand_hst` (
  `opcommand_hstid` bigint unsigned NOT NULL,
  `operationid` bigint unsigned NOT NULL,
  `hostid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`opcommand_hstid`),
  KEY `opcommand_hst_1` (`operationid`),
  KEY `opcommand_hst_2` (`hostid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opcommand_hst`
--

LOCK TABLES `opcommand_hst` WRITE;
/*!40000 ALTER TABLE `opcommand_hst` DISABLE KEYS */;
/*!40000 ALTER TABLE `opcommand_hst` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opconditions`
--

DROP TABLE IF EXISTS `opconditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opconditions` (
  `opconditionid` bigint unsigned NOT NULL,
  `operationid` bigint unsigned NOT NULL,
  `conditiontype` int NOT NULL DEFAULT '0',
  `operator` int NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`opconditionid`),
  KEY `opconditions_1` (`operationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opconditions`
--

LOCK TABLES `opconditions` WRITE;
/*!40000 ALTER TABLE `opconditions` DISABLE KEYS */;
/*!40000 ALTER TABLE `opconditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operations`
--

DROP TABLE IF EXISTS `operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operations` (
  `operationid` bigint unsigned NOT NULL,
  `actionid` bigint unsigned NOT NULL,
  `operationtype` int NOT NULL DEFAULT '0',
  `esc_period` varchar(255) NOT NULL DEFAULT '0',
  `esc_step_from` int NOT NULL DEFAULT '1',
  `esc_step_to` int NOT NULL DEFAULT '1',
  `evaltype` int NOT NULL DEFAULT '0',
  `recovery` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`operationid`),
  KEY `operations_1` (`actionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operations`
--

LOCK TABLES `operations` WRITE;
/*!40000 ALTER TABLE `operations` DISABLE KEYS */;
/*!40000 ALTER TABLE `operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opgroup`
--

DROP TABLE IF EXISTS `opgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opgroup` (
  `opgroupid` bigint unsigned NOT NULL,
  `operationid` bigint unsigned NOT NULL,
  `groupid` bigint unsigned NOT NULL,
  PRIMARY KEY (`opgroupid`),
  UNIQUE KEY `opgroup_1` (`operationid`,`groupid`),
  KEY `opgroup_2` (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opgroup`
--

LOCK TABLES `opgroup` WRITE;
/*!40000 ALTER TABLE `opgroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `opgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opinventory`
--

DROP TABLE IF EXISTS `opinventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opinventory` (
  `operationid` bigint unsigned NOT NULL,
  `inventory_mode` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`operationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opinventory`
--

LOCK TABLES `opinventory` WRITE;
/*!40000 ALTER TABLE `opinventory` DISABLE KEYS */;
/*!40000 ALTER TABLE `opinventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opmessage`
--

DROP TABLE IF EXISTS `opmessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opmessage` (
  `operationid` bigint unsigned NOT NULL,
  `default_msg` int NOT NULL DEFAULT '1',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `mediatypeid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`operationid`),
  KEY `opmessage_1` (`mediatypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opmessage`
--

LOCK TABLES `opmessage` WRITE;
/*!40000 ALTER TABLE `opmessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `opmessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opmessage_grp`
--

DROP TABLE IF EXISTS `opmessage_grp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opmessage_grp` (
  `opmessage_grpid` bigint unsigned NOT NULL,
  `operationid` bigint unsigned NOT NULL,
  `usrgrpid` bigint unsigned NOT NULL,
  PRIMARY KEY (`opmessage_grpid`),
  UNIQUE KEY `opmessage_grp_1` (`operationid`,`usrgrpid`),
  KEY `opmessage_grp_2` (`usrgrpid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opmessage_grp`
--

LOCK TABLES `opmessage_grp` WRITE;
/*!40000 ALTER TABLE `opmessage_grp` DISABLE KEYS */;
/*!40000 ALTER TABLE `opmessage_grp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opmessage_usr`
--

DROP TABLE IF EXISTS `opmessage_usr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opmessage_usr` (
  `opmessage_usrid` bigint unsigned NOT NULL,
  `operationid` bigint unsigned NOT NULL,
  `userid` bigint unsigned NOT NULL,
  PRIMARY KEY (`opmessage_usrid`),
  UNIQUE KEY `opmessage_usr_1` (`operationid`,`userid`),
  KEY `opmessage_usr_2` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opmessage_usr`
--

LOCK TABLES `opmessage_usr` WRITE;
/*!40000 ALTER TABLE `opmessage_usr` DISABLE KEYS */;
/*!40000 ALTER TABLE `opmessage_usr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `optag`
--

DROP TABLE IF EXISTS `optag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `optag` (
  `optagid` bigint unsigned NOT NULL,
  `operationid` bigint unsigned NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`optagid`),
  KEY `optag_1` (`operationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `optag`
--

LOCK TABLES `optag` WRITE;
/*!40000 ALTER TABLE `optag` DISABLE KEYS */;
/*!40000 ALTER TABLE `optag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `optemplate`
--

DROP TABLE IF EXISTS `optemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `optemplate` (
  `optemplateid` bigint unsigned NOT NULL,
  `operationid` bigint unsigned NOT NULL,
  `templateid` bigint unsigned NOT NULL,
  PRIMARY KEY (`optemplateid`),
  UNIQUE KEY `optemplate_1` (`operationid`,`templateid`),
  KEY `optemplate_2` (`templateid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `optemplate`
--

LOCK TABLES `optemplate` WRITE;
/*!40000 ALTER TABLE `optemplate` DISABLE KEYS */;
/*!40000 ALTER TABLE `optemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission` (
  `ugsetid` bigint unsigned NOT NULL,
  `hgsetid` bigint unsigned NOT NULL,
  `permission` int NOT NULL DEFAULT '2',
  PRIMARY KEY (`ugsetid`,`hgsetid`),
  KEY `permission_1` (`hgsetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `problem`
--

DROP TABLE IF EXISTS `problem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `problem` (
  `eventid` bigint unsigned NOT NULL,
  `source` int NOT NULL DEFAULT '0',
  `object` int NOT NULL DEFAULT '0',
  `objectid` bigint unsigned NOT NULL DEFAULT '0',
  `clock` int NOT NULL DEFAULT '0',
  `ns` int NOT NULL DEFAULT '0',
  `r_eventid` bigint unsigned DEFAULT NULL,
  `r_clock` int NOT NULL DEFAULT '0',
  `r_ns` int NOT NULL DEFAULT '0',
  `correlationid` bigint unsigned DEFAULT NULL,
  `userid` bigint unsigned DEFAULT NULL,
  `name` varchar(2048) NOT NULL DEFAULT '',
  `acknowledged` int NOT NULL DEFAULT '0',
  `severity` int NOT NULL DEFAULT '0',
  `cause_eventid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`eventid`),
  KEY `problem_1` (`source`,`object`,`objectid`),
  KEY `problem_2` (`r_clock`),
  KEY `problem_3` (`r_eventid`),
  KEY `problem_4` (`cause_eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `problem`
--

LOCK TABLES `problem` WRITE;
/*!40000 ALTER TABLE `problem` DISABLE KEYS */;
/*!40000 ALTER TABLE `problem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `problem_tag`
--

DROP TABLE IF EXISTS `problem_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `problem_tag` (
  `problemtagid` bigint unsigned NOT NULL,
  `eventid` bigint unsigned NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`problemtagid`),
  KEY `problem_tag_1` (`eventid`,`tag`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `problem_tag`
--

LOCK TABLES `problem_tag` WRITE;
/*!40000 ALTER TABLE `problem_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `problem_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profiles`
--

DROP TABLE IF EXISTS `profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profiles` (
  `profileid` bigint unsigned NOT NULL,
  `userid` bigint unsigned NOT NULL,
  `idx` varchar(96) NOT NULL DEFAULT '',
  `idx2` bigint unsigned NOT NULL DEFAULT '0',
  `value_id` bigint unsigned NOT NULL DEFAULT '0',
  `value_int` int NOT NULL DEFAULT '0',
  `value_str` text NOT NULL,
  `source` varchar(96) NOT NULL DEFAULT '',
  `type` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`profileid`),
  KEY `profiles_1` (`userid`,`idx`,`idx2`),
  KEY `profiles_2` (`userid`,`profileid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profiles`
--

LOCK TABLES `profiles` WRITE;
/*!40000 ALTER TABLE `profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proxy`
--

DROP TABLE IF EXISTS `proxy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proxy` (
  `proxyid` bigint unsigned NOT NULL,
  `name` varchar(128) NOT NULL DEFAULT '',
  `operating_mode` int NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `tls_connect` int NOT NULL DEFAULT '1',
  `tls_accept` int NOT NULL DEFAULT '1',
  `tls_issuer` varchar(1024) NOT NULL DEFAULT '',
  `tls_subject` varchar(1024) NOT NULL DEFAULT '',
  `tls_psk_identity` varchar(128) NOT NULL DEFAULT '',
  `tls_psk` varchar(512) NOT NULL DEFAULT '',
  `allowed_addresses` varchar(255) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '127.0.0.1',
  `port` varchar(64) NOT NULL DEFAULT '10051',
  `custom_timeouts` int NOT NULL DEFAULT '0',
  `timeout_zabbix_agent` varchar(255) NOT NULL DEFAULT '',
  `timeout_simple_check` varchar(255) NOT NULL DEFAULT '',
  `timeout_snmp_agent` varchar(255) NOT NULL DEFAULT '',
  `timeout_external_check` varchar(255) NOT NULL DEFAULT '',
  `timeout_db_monitor` varchar(255) NOT NULL DEFAULT '',
  `timeout_http_agent` varchar(255) NOT NULL DEFAULT '',
  `timeout_ssh_agent` varchar(255) NOT NULL DEFAULT '',
  `timeout_telnet_agent` varchar(255) NOT NULL DEFAULT '',
  `timeout_script` varchar(255) NOT NULL DEFAULT '',
  `local_address` varchar(255) NOT NULL DEFAULT '',
  `local_port` varchar(64) NOT NULL DEFAULT '10051',
  `proxy_groupid` bigint unsigned DEFAULT NULL,
  `timeout_browser` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`proxyid`),
  UNIQUE KEY `proxy_1` (`name`),
  KEY `proxy_2` (`proxy_groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proxy`
--

LOCK TABLES `proxy` WRITE;
/*!40000 ALTER TABLE `proxy` DISABLE KEYS */;
/*!40000 ALTER TABLE `proxy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proxy_autoreg_host`
--

DROP TABLE IF EXISTS `proxy_autoreg_host`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proxy_autoreg_host` (
  `id` bigint unsigned NOT NULL,
  `clock` int NOT NULL DEFAULT '0',
  `host` varchar(128) NOT NULL DEFAULT '',
  `listen_ip` varchar(39) NOT NULL DEFAULT '',
  `listen_port` int NOT NULL DEFAULT '0',
  `listen_dns` varchar(255) NOT NULL DEFAULT '',
  `host_metadata` text NOT NULL,
  `flags` int NOT NULL DEFAULT '0',
  `tls_accepted` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `proxy_autoreg_host_1` (`clock`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proxy_autoreg_host`
--

LOCK TABLES `proxy_autoreg_host` WRITE;
/*!40000 ALTER TABLE `proxy_autoreg_host` DISABLE KEYS */;
/*!40000 ALTER TABLE `proxy_autoreg_host` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proxy_dhistory`
--

DROP TABLE IF EXISTS `proxy_dhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proxy_dhistory` (
  `id` bigint unsigned NOT NULL,
  `clock` int NOT NULL DEFAULT '0',
  `druleid` bigint unsigned NOT NULL,
  `ip` varchar(39) NOT NULL DEFAULT '',
  `port` int NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  `status` int NOT NULL DEFAULT '0',
  `dcheckid` bigint unsigned DEFAULT NULL,
  `dns` varchar(255) NOT NULL DEFAULT '',
  `error` varchar(2048) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `proxy_dhistory_1` (`clock`),
  KEY `proxy_dhistory_2` (`druleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proxy_dhistory`
--

LOCK TABLES `proxy_dhistory` WRITE;
/*!40000 ALTER TABLE `proxy_dhistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `proxy_dhistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proxy_group`
--

DROP TABLE IF EXISTS `proxy_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proxy_group` (
  `proxy_groupid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `failover_delay` varchar(255) NOT NULL DEFAULT '1m',
  `min_online` varchar(255) NOT NULL DEFAULT '1',
  PRIMARY KEY (`proxy_groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proxy_group`
--

LOCK TABLES `proxy_group` WRITE;
/*!40000 ALTER TABLE `proxy_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `proxy_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proxy_group_rtdata`
--

DROP TABLE IF EXISTS `proxy_group_rtdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proxy_group_rtdata` (
  `proxy_groupid` bigint unsigned NOT NULL,
  `state` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`proxy_groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proxy_group_rtdata`
--

LOCK TABLES `proxy_group_rtdata` WRITE;
/*!40000 ALTER TABLE `proxy_group_rtdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `proxy_group_rtdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proxy_history`
--

DROP TABLE IF EXISTS `proxy_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proxy_history` (
  `id` bigint unsigned NOT NULL,
  `itemid` bigint unsigned NOT NULL,
  `clock` int NOT NULL DEFAULT '0',
  `timestamp` int NOT NULL DEFAULT '0',
  `source` varchar(64) NOT NULL DEFAULT '',
  `severity` int NOT NULL DEFAULT '0',
  `value` longtext NOT NULL,
  `logeventid` int NOT NULL DEFAULT '0',
  `ns` int NOT NULL DEFAULT '0',
  `state` int NOT NULL DEFAULT '0',
  `lastlogsize` bigint unsigned NOT NULL DEFAULT '0',
  `mtime` int NOT NULL DEFAULT '0',
  `flags` int NOT NULL DEFAULT '0',
  `write_clock` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `proxy_history_2` (`write_clock`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proxy_history`
--

LOCK TABLES `proxy_history` WRITE;
/*!40000 ALTER TABLE `proxy_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `proxy_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proxy_rtdata`
--

DROP TABLE IF EXISTS `proxy_rtdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proxy_rtdata` (
  `proxyid` bigint unsigned NOT NULL,
  `lastaccess` int NOT NULL DEFAULT '0',
  `version` int NOT NULL DEFAULT '0',
  `compatibility` int NOT NULL DEFAULT '0',
  `state` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`proxyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proxy_rtdata`
--

LOCK TABLES `proxy_rtdata` WRITE;
/*!40000 ALTER TABLE `proxy_rtdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `proxy_rtdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regexps`
--

DROP TABLE IF EXISTS `regexps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `regexps` (
  `regexpid` bigint unsigned NOT NULL,
  `name` varchar(128) NOT NULL DEFAULT '',
  `test_string` text NOT NULL,
  PRIMARY KEY (`regexpid`),
  UNIQUE KEY `regexps_1` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regexps`
--

LOCK TABLES `regexps` WRITE;
/*!40000 ALTER TABLE `regexps` DISABLE KEYS */;
/*!40000 ALTER TABLE `regexps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report` (
  `reportid` bigint unsigned NOT NULL,
  `userid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(2048) NOT NULL DEFAULT '',
  `status` int NOT NULL DEFAULT '0',
  `dashboardid` bigint unsigned NOT NULL,
  `period` int NOT NULL DEFAULT '0',
  `cycle` int NOT NULL DEFAULT '0',
  `weekdays` int NOT NULL DEFAULT '0',
  `start_time` int NOT NULL DEFAULT '0',
  `active_since` int NOT NULL DEFAULT '0',
  `active_till` int NOT NULL DEFAULT '0',
  `state` int NOT NULL DEFAULT '0',
  `lastsent` int NOT NULL DEFAULT '0',
  `info` varchar(2048) NOT NULL DEFAULT '',
  PRIMARY KEY (`reportid`),
  UNIQUE KEY `report_1` (`name`),
  KEY `report_2` (`userid`),
  KEY `report_3` (`dashboardid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report`
--

LOCK TABLES `report` WRITE;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_param`
--

DROP TABLE IF EXISTS `report_param`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_param` (
  `reportparamid` bigint unsigned NOT NULL,
  `reportid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`reportparamid`),
  KEY `report_param_1` (`reportid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_param`
--

LOCK TABLES `report_param` WRITE;
/*!40000 ALTER TABLE `report_param` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_param` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_user`
--

DROP TABLE IF EXISTS `report_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_user` (
  `reportuserid` bigint unsigned NOT NULL,
  `reportid` bigint unsigned NOT NULL,
  `userid` bigint unsigned NOT NULL,
  `exclude` int NOT NULL DEFAULT '0',
  `access_userid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`reportuserid`),
  KEY `report_user_1` (`reportid`),
  KEY `report_user_2` (`userid`),
  KEY `report_user_3` (`access_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_user`
--

LOCK TABLES `report_user` WRITE;
/*!40000 ALTER TABLE `report_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_usrgrp`
--

DROP TABLE IF EXISTS `report_usrgrp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_usrgrp` (
  `reportusrgrpid` bigint unsigned NOT NULL,
  `reportid` bigint unsigned NOT NULL,
  `usrgrpid` bigint unsigned NOT NULL,
  `access_userid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`reportusrgrpid`),
  KEY `report_usrgrp_1` (`reportid`),
  KEY `report_usrgrp_2` (`usrgrpid`),
  KEY `report_usrgrp_3` (`access_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_usrgrp`
--

LOCK TABLES `report_usrgrp` WRITE;
/*!40000 ALTER TABLE `report_usrgrp` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_usrgrp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rights`
--

DROP TABLE IF EXISTS `rights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rights` (
  `rightid` bigint unsigned NOT NULL,
  `groupid` bigint unsigned NOT NULL,
  `permission` int NOT NULL DEFAULT '0',
  `id` bigint unsigned NOT NULL,
  PRIMARY KEY (`rightid`),
  KEY `rights_1` (`groupid`),
  KEY `rights_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rights`
--

LOCK TABLES `rights` WRITE;
/*!40000 ALTER TABLE `rights` DISABLE KEYS */;
/*!40000 ALTER TABLE `rights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `roleid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` int NOT NULL DEFAULT '0',
  `readonly` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`roleid`),
  UNIQUE KEY `role_1` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_rule`
--

DROP TABLE IF EXISTS `role_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_rule` (
  `role_ruleid` bigint unsigned NOT NULL,
  `roleid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `value_int` int NOT NULL DEFAULT '0',
  `value_str` varchar(255) NOT NULL DEFAULT '',
  `value_moduleid` bigint unsigned DEFAULT NULL,
  `value_serviceid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`role_ruleid`),
  KEY `role_rule_1` (`roleid`),
  KEY `role_rule_2` (`value_moduleid`),
  KEY `role_rule_3` (`value_serviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_rule`
--

LOCK TABLES `role_rule` WRITE;
/*!40000 ALTER TABLE `role_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scim_group`
--

DROP TABLE IF EXISTS `scim_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scim_group` (
  `scim_groupid` bigint unsigned NOT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`scim_groupid`),
  UNIQUE KEY `scim_group_1` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scim_group`
--

LOCK TABLES `scim_group` WRITE;
/*!40000 ALTER TABLE `scim_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `scim_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `script_param`
--

DROP TABLE IF EXISTS `script_param`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `script_param` (
  `script_paramid` bigint unsigned NOT NULL,
  `scriptid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(2048) NOT NULL DEFAULT '',
  PRIMARY KEY (`script_paramid`),
  UNIQUE KEY `script_param_1` (`scriptid`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `script_param`
--

LOCK TABLES `script_param` WRITE;
/*!40000 ALTER TABLE `script_param` DISABLE KEYS */;
/*!40000 ALTER TABLE `script_param` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scripts`
--

DROP TABLE IF EXISTS `scripts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scripts` (
  `scriptid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `command` text NOT NULL,
  `host_access` int NOT NULL DEFAULT '2',
  `usrgrpid` bigint unsigned DEFAULT NULL,
  `groupid` bigint unsigned DEFAULT NULL,
  `description` text NOT NULL,
  `confirmation` varchar(255) NOT NULL DEFAULT '',
  `type` int NOT NULL DEFAULT '5',
  `execute_on` int NOT NULL DEFAULT '2',
  `timeout` varchar(32) NOT NULL DEFAULT '30s',
  `scope` int NOT NULL DEFAULT '1',
  `port` varchar(64) NOT NULL DEFAULT '',
  `authtype` int NOT NULL DEFAULT '0',
  `username` varchar(64) NOT NULL DEFAULT '',
  `password` varchar(64) NOT NULL DEFAULT '',
  `publickey` varchar(64) NOT NULL DEFAULT '',
  `privatekey` varchar(64) NOT NULL DEFAULT '',
  `menu_path` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(2048) NOT NULL DEFAULT '',
  `new_window` int NOT NULL DEFAULT '1',
  `manualinput` int NOT NULL DEFAULT '0',
  `manualinput_prompt` varchar(255) NOT NULL DEFAULT '',
  `manualinput_validator` varchar(2048) NOT NULL DEFAULT '',
  `manualinput_validator_type` int NOT NULL DEFAULT '0',
  `manualinput_default_value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`scriptid`),
  UNIQUE KEY `scripts_3` (`name`,`menu_path`),
  KEY `scripts_1` (`usrgrpid`),
  KEY `scripts_2` (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scripts`
--

LOCK TABLES `scripts` WRITE;
/*!40000 ALTER TABLE `scripts` DISABLE KEYS */;
/*!40000 ALTER TABLE `scripts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_alarms`
--

DROP TABLE IF EXISTS `service_alarms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_alarms` (
  `servicealarmid` bigint unsigned NOT NULL,
  `serviceid` bigint unsigned NOT NULL,
  `clock` int NOT NULL DEFAULT '0',
  `value` int NOT NULL DEFAULT '-1',
  PRIMARY KEY (`servicealarmid`),
  KEY `service_alarms_1` (`serviceid`,`clock`),
  KEY `service_alarms_2` (`clock`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_alarms`
--

LOCK TABLES `service_alarms` WRITE;
/*!40000 ALTER TABLE `service_alarms` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_alarms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_problem`
--

DROP TABLE IF EXISTS `service_problem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_problem` (
  `service_problemid` bigint unsigned NOT NULL,
  `eventid` bigint unsigned NOT NULL,
  `serviceid` bigint unsigned NOT NULL,
  `severity` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`service_problemid`),
  KEY `service_problem_1` (`eventid`),
  KEY `service_problem_2` (`serviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_problem`
--

LOCK TABLES `service_problem` WRITE;
/*!40000 ALTER TABLE `service_problem` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_problem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_problem_tag`
--

DROP TABLE IF EXISTS `service_problem_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_problem_tag` (
  `service_problem_tagid` bigint unsigned NOT NULL,
  `serviceid` bigint unsigned NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `operator` int NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`service_problem_tagid`),
  KEY `service_problem_tag_1` (`serviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_problem_tag`
--

LOCK TABLES `service_problem_tag` WRITE;
/*!40000 ALTER TABLE `service_problem_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_problem_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_status_rule`
--

DROP TABLE IF EXISTS `service_status_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_status_rule` (
  `service_status_ruleid` bigint unsigned NOT NULL,
  `serviceid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `limit_value` int NOT NULL DEFAULT '0',
  `limit_status` int NOT NULL DEFAULT '0',
  `new_status` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`service_status_ruleid`),
  KEY `service_status_rule_1` (`serviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_status_rule`
--

LOCK TABLES `service_status_rule` WRITE;
/*!40000 ALTER TABLE `service_status_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_status_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_tag`
--

DROP TABLE IF EXISTS `service_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_tag` (
  `servicetagid` bigint unsigned NOT NULL,
  `serviceid` bigint unsigned NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`servicetagid`),
  KEY `service_tag_1` (`serviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_tag`
--

LOCK TABLES `service_tag` WRITE;
/*!40000 ALTER TABLE `service_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `services` (
  `serviceid` bigint unsigned NOT NULL,
  `name` varchar(128) NOT NULL DEFAULT '',
  `status` int NOT NULL DEFAULT '-1',
  `algorithm` int NOT NULL DEFAULT '0',
  `sortorder` int NOT NULL DEFAULT '0',
  `weight` int NOT NULL DEFAULT '0',
  `propagation_rule` int NOT NULL DEFAULT '0',
  `propagation_value` int NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `uuid` varchar(32) NOT NULL DEFAULT '',
  `created_at` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`serviceid`),
  KEY `services_1` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services_links`
--

DROP TABLE IF EXISTS `services_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `services_links` (
  `linkid` bigint unsigned NOT NULL,
  `serviceupid` bigint unsigned NOT NULL,
  `servicedownid` bigint unsigned NOT NULL,
  PRIMARY KEY (`linkid`),
  UNIQUE KEY `services_links_2` (`serviceupid`,`servicedownid`),
  KEY `services_links_1` (`servicedownid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services_links`
--

LOCK TABLES `services_links` WRITE;
/*!40000 ALTER TABLE `services_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `services_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `sessionid` varchar(32) NOT NULL DEFAULT '',
  `userid` bigint unsigned NOT NULL,
  `lastaccess` int NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '0',
  `secret` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`sessionid`),
  KEY `sessions_1` (`userid`,`status`,`lastaccess`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `name` varchar(255) NOT NULL,
  `type` int NOT NULL,
  `value_str` text NOT NULL,
  `value_int` int NOT NULL DEFAULT '0',
  `value_usrgrpid` bigint unsigned DEFAULT NULL,
  `value_hostgroupid` bigint unsigned DEFAULT NULL,
  `value_userdirectoryid` bigint unsigned DEFAULT NULL,
  `value_mfaid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `settings_2` (`value_usrgrpid`),
  KEY `settings_3` (`value_hostgroupid`),
  KEY `settings_4` (`value_userdirectoryid`),
  KEY `settings_5` (`value_mfaid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sla`
--

DROP TABLE IF EXISTS `sla`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sla` (
  `slaid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `period` int NOT NULL DEFAULT '0',
  `slo` double NOT NULL DEFAULT '99.9',
  `effective_date` int NOT NULL DEFAULT '0',
  `timezone` varchar(50) NOT NULL DEFAULT 'UTC',
  `status` int NOT NULL DEFAULT '1',
  `description` text NOT NULL,
  PRIMARY KEY (`slaid`),
  UNIQUE KEY `sla_1` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sla`
--

LOCK TABLES `sla` WRITE;
/*!40000 ALTER TABLE `sla` DISABLE KEYS */;
/*!40000 ALTER TABLE `sla` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sla_excluded_downtime`
--

DROP TABLE IF EXISTS `sla_excluded_downtime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sla_excluded_downtime` (
  `sla_excluded_downtimeid` bigint unsigned NOT NULL,
  `slaid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `period_from` int NOT NULL DEFAULT '0',
  `period_to` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`sla_excluded_downtimeid`),
  KEY `sla_excluded_downtime_1` (`slaid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sla_excluded_downtime`
--

LOCK TABLES `sla_excluded_downtime` WRITE;
/*!40000 ALTER TABLE `sla_excluded_downtime` DISABLE KEYS */;
/*!40000 ALTER TABLE `sla_excluded_downtime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sla_schedule`
--

DROP TABLE IF EXISTS `sla_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sla_schedule` (
  `sla_scheduleid` bigint unsigned NOT NULL,
  `slaid` bigint unsigned NOT NULL,
  `period_from` int NOT NULL DEFAULT '0',
  `period_to` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`sla_scheduleid`),
  KEY `sla_schedule_1` (`slaid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sla_schedule`
--

LOCK TABLES `sla_schedule` WRITE;
/*!40000 ALTER TABLE `sla_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `sla_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sla_service_tag`
--

DROP TABLE IF EXISTS `sla_service_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sla_service_tag` (
  `sla_service_tagid` bigint unsigned NOT NULL,
  `slaid` bigint unsigned NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `operator` int NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`sla_service_tagid`),
  KEY `sla_service_tag_1` (`slaid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sla_service_tag`
--

LOCK TABLES `sla_service_tag` WRITE;
/*!40000 ALTER TABLE `sla_service_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `sla_service_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sysmap_element_trigger`
--

DROP TABLE IF EXISTS `sysmap_element_trigger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysmap_element_trigger` (
  `selement_triggerid` bigint unsigned NOT NULL,
  `selementid` bigint unsigned NOT NULL,
  `triggerid` bigint unsigned NOT NULL,
  PRIMARY KEY (`selement_triggerid`),
  UNIQUE KEY `sysmap_element_trigger_1` (`selementid`,`triggerid`),
  KEY `sysmap_element_trigger_2` (`triggerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysmap_element_trigger`
--

LOCK TABLES `sysmap_element_trigger` WRITE;
/*!40000 ALTER TABLE `sysmap_element_trigger` DISABLE KEYS */;
/*!40000 ALTER TABLE `sysmap_element_trigger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sysmap_element_url`
--

DROP TABLE IF EXISTS `sysmap_element_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysmap_element_url` (
  `sysmapelementurlid` bigint unsigned NOT NULL,
  `selementid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `url` varchar(2048) NOT NULL DEFAULT '',
  PRIMARY KEY (`sysmapelementurlid`),
  UNIQUE KEY `sysmap_element_url_1` (`selementid`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysmap_element_url`
--

LOCK TABLES `sysmap_element_url` WRITE;
/*!40000 ALTER TABLE `sysmap_element_url` DISABLE KEYS */;
/*!40000 ALTER TABLE `sysmap_element_url` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sysmap_link_threshold`
--

DROP TABLE IF EXISTS `sysmap_link_threshold`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysmap_link_threshold` (
  `linkthresholdid` bigint unsigned NOT NULL,
  `linkid` bigint unsigned NOT NULL,
  `drawtype` int NOT NULL DEFAULT '0',
  `color` varchar(6) NOT NULL DEFAULT '000000',
  `type` int NOT NULL DEFAULT '0',
  `threshold` varchar(255) NOT NULL DEFAULT '',
  `pattern` varchar(255) NOT NULL DEFAULT '',
  `sortorder` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`linkthresholdid`),
  KEY `sysmap_link_threshold_1` (`linkid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysmap_link_threshold`
--

LOCK TABLES `sysmap_link_threshold` WRITE;
/*!40000 ALTER TABLE `sysmap_link_threshold` DISABLE KEYS */;
/*!40000 ALTER TABLE `sysmap_link_threshold` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sysmap_shape`
--

DROP TABLE IF EXISTS `sysmap_shape`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysmap_shape` (
  `sysmap_shapeid` bigint unsigned NOT NULL,
  `sysmapid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `x` int NOT NULL DEFAULT '0',
  `y` int NOT NULL DEFAULT '0',
  `width` int NOT NULL DEFAULT '200',
  `height` int NOT NULL DEFAULT '200',
  `text` text NOT NULL,
  `font` int NOT NULL DEFAULT '9',
  `font_size` int NOT NULL DEFAULT '11',
  `font_color` varchar(6) NOT NULL DEFAULT '000000',
  `text_halign` int NOT NULL DEFAULT '0',
  `text_valign` int NOT NULL DEFAULT '0',
  `border_type` int NOT NULL DEFAULT '0',
  `border_width` int NOT NULL DEFAULT '1',
  `border_color` varchar(6) NOT NULL DEFAULT '000000',
  `background_color` varchar(6) NOT NULL DEFAULT '',
  `zindex` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`sysmap_shapeid`),
  KEY `sysmap_shape_1` (`sysmapid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysmap_shape`
--

LOCK TABLES `sysmap_shape` WRITE;
/*!40000 ALTER TABLE `sysmap_shape` DISABLE KEYS */;
/*!40000 ALTER TABLE `sysmap_shape` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sysmap_url`
--

DROP TABLE IF EXISTS `sysmap_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysmap_url` (
  `sysmapurlid` bigint unsigned NOT NULL,
  `sysmapid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `url` varchar(2048) NOT NULL DEFAULT '',
  `elementtype` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`sysmapurlid`),
  UNIQUE KEY `sysmap_url_1` (`sysmapid`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysmap_url`
--

LOCK TABLES `sysmap_url` WRITE;
/*!40000 ALTER TABLE `sysmap_url` DISABLE KEYS */;
/*!40000 ALTER TABLE `sysmap_url` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sysmap_user`
--

DROP TABLE IF EXISTS `sysmap_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysmap_user` (
  `sysmapuserid` bigint unsigned NOT NULL,
  `sysmapid` bigint unsigned NOT NULL,
  `userid` bigint unsigned NOT NULL,
  `permission` int NOT NULL DEFAULT '2',
  PRIMARY KEY (`sysmapuserid`),
  UNIQUE KEY `sysmap_user_1` (`sysmapid`,`userid`),
  KEY `sysmap_user_2` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysmap_user`
--

LOCK TABLES `sysmap_user` WRITE;
/*!40000 ALTER TABLE `sysmap_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `sysmap_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sysmap_usrgrp`
--

DROP TABLE IF EXISTS `sysmap_usrgrp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysmap_usrgrp` (
  `sysmapusrgrpid` bigint unsigned NOT NULL,
  `sysmapid` bigint unsigned NOT NULL,
  `usrgrpid` bigint unsigned NOT NULL,
  `permission` int NOT NULL DEFAULT '2',
  PRIMARY KEY (`sysmapusrgrpid`),
  UNIQUE KEY `sysmap_usrgrp_1` (`sysmapid`,`usrgrpid`),
  KEY `sysmap_usrgrp_2` (`usrgrpid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysmap_usrgrp`
--

LOCK TABLES `sysmap_usrgrp` WRITE;
/*!40000 ALTER TABLE `sysmap_usrgrp` DISABLE KEYS */;
/*!40000 ALTER TABLE `sysmap_usrgrp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sysmaps`
--

DROP TABLE IF EXISTS `sysmaps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysmaps` (
  `sysmapid` bigint unsigned NOT NULL,
  `name` varchar(128) NOT NULL DEFAULT '',
  `width` int NOT NULL DEFAULT '600',
  `height` int NOT NULL DEFAULT '400',
  `backgroundid` bigint unsigned DEFAULT NULL,
  `label_type` int NOT NULL DEFAULT '2',
  `label_location` int NOT NULL DEFAULT '0',
  `highlight` int NOT NULL DEFAULT '1',
  `expandproblem` int NOT NULL DEFAULT '1',
  `markelements` int NOT NULL DEFAULT '0',
  `show_unack` int NOT NULL DEFAULT '0',
  `grid_size` int NOT NULL DEFAULT '50',
  `grid_show` int NOT NULL DEFAULT '1',
  `grid_align` int NOT NULL DEFAULT '1',
  `label_format` int NOT NULL DEFAULT '0',
  `label_type_host` int NOT NULL DEFAULT '2',
  `label_type_hostgroup` int NOT NULL DEFAULT '2',
  `label_type_trigger` int NOT NULL DEFAULT '2',
  `label_type_map` int NOT NULL DEFAULT '2',
  `label_type_image` int NOT NULL DEFAULT '2',
  `label_string_host` varchar(255) NOT NULL DEFAULT '',
  `label_string_hostgroup` varchar(255) NOT NULL DEFAULT '',
  `label_string_trigger` varchar(255) NOT NULL DEFAULT '',
  `label_string_map` varchar(255) NOT NULL DEFAULT '',
  `label_string_image` varchar(255) NOT NULL DEFAULT '',
  `iconmapid` bigint unsigned DEFAULT NULL,
  `expand_macros` int NOT NULL DEFAULT '0',
  `severity_min` int NOT NULL DEFAULT '0',
  `userid` bigint unsigned NOT NULL,
  `private` int NOT NULL DEFAULT '1',
  `show_suppressed` int NOT NULL DEFAULT '0',
  `background_scale` int NOT NULL DEFAULT '1',
  `show_element_label` int NOT NULL DEFAULT '1',
  `show_link_label` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`sysmapid`),
  UNIQUE KEY `sysmaps_1` (`name`),
  KEY `sysmaps_2` (`backgroundid`),
  KEY `sysmaps_3` (`iconmapid`),
  KEY `sysmaps_4` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysmaps`
--

LOCK TABLES `sysmaps` WRITE;
/*!40000 ALTER TABLE `sysmaps` DISABLE KEYS */;
/*!40000 ALTER TABLE `sysmaps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sysmaps_element_tag`
--

DROP TABLE IF EXISTS `sysmaps_element_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysmaps_element_tag` (
  `selementtagid` bigint unsigned NOT NULL,
  `selementid` bigint unsigned NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  `operator` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`selementtagid`),
  KEY `sysmaps_element_tag_1` (`selementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysmaps_element_tag`
--

LOCK TABLES `sysmaps_element_tag` WRITE;
/*!40000 ALTER TABLE `sysmaps_element_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `sysmaps_element_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sysmaps_elements`
--

DROP TABLE IF EXISTS `sysmaps_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysmaps_elements` (
  `selementid` bigint unsigned NOT NULL,
  `sysmapid` bigint unsigned NOT NULL,
  `elementid` bigint unsigned NOT NULL DEFAULT '0',
  `elementtype` int NOT NULL DEFAULT '0',
  `iconid_off` bigint unsigned DEFAULT NULL,
  `iconid_on` bigint unsigned DEFAULT NULL,
  `label` varchar(2048) NOT NULL DEFAULT '',
  `label_location` int NOT NULL DEFAULT '-1',
  `x` int NOT NULL DEFAULT '0',
  `y` int NOT NULL DEFAULT '0',
  `iconid_disabled` bigint unsigned DEFAULT NULL,
  `iconid_maintenance` bigint unsigned DEFAULT NULL,
  `elementsubtype` int NOT NULL DEFAULT '0',
  `areatype` int NOT NULL DEFAULT '0',
  `width` int NOT NULL DEFAULT '200',
  `height` int NOT NULL DEFAULT '200',
  `viewtype` int NOT NULL DEFAULT '0',
  `use_iconmap` int NOT NULL DEFAULT '1',
  `evaltype` int NOT NULL DEFAULT '0',
  `show_label` int NOT NULL DEFAULT '-1',
  `zindex` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`selementid`),
  KEY `sysmaps_elements_1` (`sysmapid`),
  KEY `sysmaps_elements_2` (`iconid_off`),
  KEY `sysmaps_elements_3` (`iconid_on`),
  KEY `sysmaps_elements_4` (`iconid_disabled`),
  KEY `sysmaps_elements_5` (`iconid_maintenance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysmaps_elements`
--

LOCK TABLES `sysmaps_elements` WRITE;
/*!40000 ALTER TABLE `sysmaps_elements` DISABLE KEYS */;
/*!40000 ALTER TABLE `sysmaps_elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sysmaps_link_triggers`
--

DROP TABLE IF EXISTS `sysmaps_link_triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysmaps_link_triggers` (
  `linktriggerid` bigint unsigned NOT NULL,
  `linkid` bigint unsigned NOT NULL,
  `triggerid` bigint unsigned NOT NULL,
  `drawtype` int NOT NULL DEFAULT '0',
  `color` varchar(6) NOT NULL DEFAULT '000000',
  PRIMARY KEY (`linktriggerid`),
  UNIQUE KEY `sysmaps_link_triggers_1` (`linkid`,`triggerid`),
  KEY `sysmaps_link_triggers_2` (`triggerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysmaps_link_triggers`
--

LOCK TABLES `sysmaps_link_triggers` WRITE;
/*!40000 ALTER TABLE `sysmaps_link_triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `sysmaps_link_triggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sysmaps_links`
--

DROP TABLE IF EXISTS `sysmaps_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysmaps_links` (
  `linkid` bigint unsigned NOT NULL,
  `sysmapid` bigint unsigned NOT NULL,
  `selementid1` bigint unsigned NOT NULL,
  `selementid2` bigint unsigned NOT NULL,
  `drawtype` int NOT NULL DEFAULT '0',
  `color` varchar(6) NOT NULL DEFAULT '000000',
  `label` varchar(2048) NOT NULL DEFAULT '',
  `show_label` int NOT NULL DEFAULT '-1',
  `indicator_type` int NOT NULL DEFAULT '0',
  `itemid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`linkid`),
  KEY `sysmaps_links_1` (`sysmapid`),
  KEY `sysmaps_links_2` (`selementid1`),
  KEY `sysmaps_links_3` (`selementid2`),
  KEY `sysmaps_links_4` (`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysmaps_links`
--

LOCK TABLES `sysmaps_links` WRITE;
/*!40000 ALTER TABLE `sysmaps_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `sysmaps_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_filter`
--

DROP TABLE IF EXISTS `tag_filter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag_filter` (
  `tag_filterid` bigint unsigned NOT NULL,
  `usrgrpid` bigint unsigned NOT NULL,
  `groupid` bigint unsigned NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`tag_filterid`),
  KEY `tag_filter_1` (`usrgrpid`),
  KEY `tag_filter_2` (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_filter`
--

LOCK TABLES `tag_filter` WRITE;
/*!40000 ALTER TABLE `tag_filter` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag_filter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task`
--

DROP TABLE IF EXISTS `task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `task` (
  `taskid` bigint unsigned NOT NULL,
  `type` int NOT NULL,
  `status` int NOT NULL DEFAULT '0',
  `clock` int NOT NULL DEFAULT '0',
  `ttl` int NOT NULL DEFAULT '0',
  `proxyid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`taskid`),
  KEY `task_1` (`status`,`proxyid`),
  KEY `task_2` (`proxyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task`
--

LOCK TABLES `task` WRITE;
/*!40000 ALTER TABLE `task` DISABLE KEYS */;
/*!40000 ALTER TABLE `task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_acknowledge`
--

DROP TABLE IF EXISTS `task_acknowledge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_acknowledge` (
  `taskid` bigint unsigned NOT NULL,
  `acknowledgeid` bigint unsigned NOT NULL,
  PRIMARY KEY (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_acknowledge`
--

LOCK TABLES `task_acknowledge` WRITE;
/*!40000 ALTER TABLE `task_acknowledge` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_acknowledge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_check_now`
--

DROP TABLE IF EXISTS `task_check_now`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_check_now` (
  `taskid` bigint unsigned NOT NULL,
  `itemid` bigint unsigned NOT NULL,
  PRIMARY KEY (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_check_now`
--

LOCK TABLES `task_check_now` WRITE;
/*!40000 ALTER TABLE `task_check_now` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_check_now` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_close_problem`
--

DROP TABLE IF EXISTS `task_close_problem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_close_problem` (
  `taskid` bigint unsigned NOT NULL,
  `acknowledgeid` bigint unsigned NOT NULL,
  PRIMARY KEY (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_close_problem`
--

LOCK TABLES `task_close_problem` WRITE;
/*!40000 ALTER TABLE `task_close_problem` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_close_problem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_data`
--

DROP TABLE IF EXISTS `task_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_data` (
  `taskid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `parent_taskid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_data`
--

LOCK TABLES `task_data` WRITE;
/*!40000 ALTER TABLE `task_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_remote_command`
--

DROP TABLE IF EXISTS `task_remote_command`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_remote_command` (
  `taskid` bigint unsigned NOT NULL,
  `command_type` int NOT NULL DEFAULT '0',
  `execute_on` int NOT NULL DEFAULT '0',
  `port` int NOT NULL DEFAULT '0',
  `authtype` int NOT NULL DEFAULT '0',
  `username` varchar(64) NOT NULL DEFAULT '',
  `password` varchar(64) NOT NULL DEFAULT '',
  `publickey` varchar(64) NOT NULL DEFAULT '',
  `privatekey` varchar(64) NOT NULL DEFAULT '',
  `command` text NOT NULL,
  `alertid` bigint unsigned DEFAULT NULL,
  `parent_taskid` bigint unsigned NOT NULL,
  `hostid` bigint unsigned NOT NULL,
  PRIMARY KEY (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_remote_command`
--

LOCK TABLES `task_remote_command` WRITE;
/*!40000 ALTER TABLE `task_remote_command` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_remote_command` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_remote_command_result`
--

DROP TABLE IF EXISTS `task_remote_command_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_remote_command_result` (
  `taskid` bigint unsigned NOT NULL,
  `status` int NOT NULL DEFAULT '0',
  `parent_taskid` bigint unsigned NOT NULL,
  `info` longtext NOT NULL,
  PRIMARY KEY (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_remote_command_result`
--

LOCK TABLES `task_remote_command_result` WRITE;
/*!40000 ALTER TABLE `task_remote_command_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_remote_command_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_result`
--

DROP TABLE IF EXISTS `task_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_result` (
  `taskid` bigint unsigned NOT NULL,
  `status` int NOT NULL DEFAULT '0',
  `parent_taskid` bigint unsigned NOT NULL,
  `info` longtext NOT NULL,
  PRIMARY KEY (`taskid`),
  KEY `task_result_1` (`parent_taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_result`
--

LOCK TABLES `task_result` WRITE;
/*!40000 ALTER TABLE `task_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timeperiods`
--

DROP TABLE IF EXISTS `timeperiods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `timeperiods` (
  `timeperiodid` bigint unsigned NOT NULL,
  `timeperiod_type` int NOT NULL DEFAULT '0',
  `every` int NOT NULL DEFAULT '1',
  `month` int NOT NULL DEFAULT '0',
  `dayofweek` int NOT NULL DEFAULT '0',
  `day` int NOT NULL DEFAULT '0',
  `start_time` int NOT NULL DEFAULT '0',
  `period` int NOT NULL DEFAULT '0',
  `start_date` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`timeperiodid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timeperiods`
--

LOCK TABLES `timeperiods` WRITE;
/*!40000 ALTER TABLE `timeperiods` DISABLE KEYS */;
/*!40000 ALTER TABLE `timeperiods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token`
--

DROP TABLE IF EXISTS `token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `token` (
  `tokenid` bigint unsigned NOT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `userid` bigint unsigned NOT NULL,
  `token` varchar(128) DEFAULT NULL,
  `lastaccess` int NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '0',
  `expires_at` int NOT NULL DEFAULT '0',
  `created_at` int NOT NULL DEFAULT '0',
  `creator_userid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`tokenid`),
  UNIQUE KEY `token_2` (`userid`,`name`),
  UNIQUE KEY `token_3` (`token`),
  KEY `token_1` (`name`),
  KEY `token_4` (`creator_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token`
--

LOCK TABLES `token` WRITE;
/*!40000 ALTER TABLE `token` DISABLE KEYS */;
/*!40000 ALTER TABLE `token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trends`
--

DROP TABLE IF EXISTS `trends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trends` (
  `itemid` bigint unsigned NOT NULL,
  `clock` int NOT NULL DEFAULT '0',
  `num` int NOT NULL DEFAULT '0',
  `value_min` double NOT NULL DEFAULT '0',
  `value_avg` double NOT NULL DEFAULT '0',
  `value_max` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`,`clock`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trends`
--

LOCK TABLES `trends` WRITE;
/*!40000 ALTER TABLE `trends` DISABLE KEYS */;
/*!40000 ALTER TABLE `trends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trends_uint`
--

DROP TABLE IF EXISTS `trends_uint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trends_uint` (
  `itemid` bigint unsigned NOT NULL,
  `clock` int NOT NULL DEFAULT '0',
  `num` int NOT NULL DEFAULT '0',
  `value_min` bigint unsigned NOT NULL DEFAULT '0',
  `value_avg` bigint unsigned NOT NULL DEFAULT '0',
  `value_max` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`,`clock`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trends_uint`
--

LOCK TABLES `trends_uint` WRITE;
/*!40000 ALTER TABLE `trends_uint` DISABLE KEYS */;
/*!40000 ALTER TABLE `trends_uint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trigger_depends`
--

DROP TABLE IF EXISTS `trigger_depends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trigger_depends` (
  `triggerdepid` bigint unsigned NOT NULL,
  `triggerid_down` bigint unsigned NOT NULL,
  `triggerid_up` bigint unsigned NOT NULL,
  PRIMARY KEY (`triggerdepid`),
  UNIQUE KEY `trigger_depends_1` (`triggerid_down`,`triggerid_up`),
  KEY `trigger_depends_2` (`triggerid_up`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trigger_depends`
--

LOCK TABLES `trigger_depends` WRITE;
/*!40000 ALTER TABLE `trigger_depends` DISABLE KEYS */;
/*!40000 ALTER TABLE `trigger_depends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trigger_discovery`
--

DROP TABLE IF EXISTS `trigger_discovery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trigger_discovery` (
  `triggerid` bigint unsigned NOT NULL,
  `parent_triggerid` bigint unsigned NOT NULL,
  `lastcheck` int NOT NULL DEFAULT '0',
  `ts_delete` int NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '0',
  `disable_source` int NOT NULL DEFAULT '0',
  `ts_disable` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`triggerid`),
  KEY `trigger_discovery_1` (`parent_triggerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trigger_discovery`
--

LOCK TABLES `trigger_discovery` WRITE;
/*!40000 ALTER TABLE `trigger_discovery` DISABLE KEYS */;
/*!40000 ALTER TABLE `trigger_discovery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trigger_queue`
--

DROP TABLE IF EXISTS `trigger_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trigger_queue` (
  `trigger_queueid` bigint unsigned NOT NULL,
  `objectid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `clock` int NOT NULL DEFAULT '0',
  `ns` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`trigger_queueid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trigger_queue`
--

LOCK TABLES `trigger_queue` WRITE;
/*!40000 ALTER TABLE `trigger_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `trigger_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trigger_tag`
--

DROP TABLE IF EXISTS `trigger_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trigger_tag` (
  `triggertagid` bigint unsigned NOT NULL,
  `triggerid` bigint unsigned NOT NULL,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`triggertagid`),
  KEY `trigger_tag_1` (`triggerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trigger_tag`
--

LOCK TABLES `trigger_tag` WRITE;
/*!40000 ALTER TABLE `trigger_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `trigger_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `triggers`
--

DROP TABLE IF EXISTS `triggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `triggers` (
  `triggerid` bigint unsigned NOT NULL,
  `expression` varchar(2048) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(2048) NOT NULL DEFAULT '',
  `status` int NOT NULL DEFAULT '0',
  `value` int NOT NULL DEFAULT '0',
  `priority` int NOT NULL DEFAULT '0',
  `lastchange` int NOT NULL DEFAULT '0',
  `comments` text NOT NULL,
  `error` varchar(2048) NOT NULL DEFAULT '',
  `templateid` bigint unsigned DEFAULT NULL,
  `type` int NOT NULL DEFAULT '0',
  `state` int NOT NULL DEFAULT '0',
  `flags` int NOT NULL DEFAULT '0',
  `recovery_mode` int NOT NULL DEFAULT '0',
  `recovery_expression` varchar(2048) NOT NULL DEFAULT '',
  `correlation_mode` int NOT NULL DEFAULT '0',
  `correlation_tag` varchar(255) NOT NULL DEFAULT '',
  `manual_close` int NOT NULL DEFAULT '0',
  `opdata` varchar(255) NOT NULL DEFAULT '',
  `discover` int NOT NULL DEFAULT '0',
  `event_name` varchar(2048) NOT NULL DEFAULT '',
  `uuid` varchar(32) NOT NULL DEFAULT '',
  `url_name` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`triggerid`),
  KEY `triggers_1` (`status`),
  KEY `triggers_2` (`value`,`lastchange`),
  KEY `triggers_3` (`templateid`),
  KEY `triggers_4` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `triggers`
--

LOCK TABLES `triggers` WRITE;
/*!40000 ALTER TABLE `triggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `triggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ugset`
--

DROP TABLE IF EXISTS `ugset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ugset` (
  `ugsetid` bigint unsigned NOT NULL,
  `hash` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`ugsetid`),
  KEY `ugset_1` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ugset`
--

LOCK TABLES `ugset` WRITE;
/*!40000 ALTER TABLE `ugset` DISABLE KEYS */;
/*!40000 ALTER TABLE `ugset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ugset_group`
--

DROP TABLE IF EXISTS `ugset_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ugset_group` (
  `ugsetid` bigint unsigned NOT NULL,
  `usrgrpid` bigint unsigned NOT NULL,
  PRIMARY KEY (`ugsetid`,`usrgrpid`),
  KEY `ugset_group_1` (`usrgrpid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ugset_group`
--

LOCK TABLES `ugset_group` WRITE;
/*!40000 ALTER TABLE `ugset_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `ugset_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_scim_group`
--

DROP TABLE IF EXISTS `user_scim_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_scim_group` (
  `user_scim_groupid` bigint unsigned NOT NULL,
  `userid` bigint unsigned NOT NULL,
  `scim_groupid` bigint unsigned NOT NULL,
  PRIMARY KEY (`user_scim_groupid`),
  KEY `user_scim_group_1` (`userid`),
  KEY `user_scim_group_2` (`scim_groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_scim_group`
--

LOCK TABLES `user_scim_group` WRITE;
/*!40000 ALTER TABLE `user_scim_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_scim_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_ugset`
--

DROP TABLE IF EXISTS `user_ugset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_ugset` (
  `userid` bigint unsigned NOT NULL,
  `ugsetid` bigint unsigned NOT NULL,
  PRIMARY KEY (`userid`),
  KEY `user_ugset_1` (`ugsetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_ugset`
--

LOCK TABLES `user_ugset` WRITE;
/*!40000 ALTER TABLE `user_ugset` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_ugset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userdirectory`
--

DROP TABLE IF EXISTS `userdirectory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userdirectory` (
  `userdirectoryid` bigint unsigned NOT NULL,
  `name` varchar(128) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `idp_type` int NOT NULL DEFAULT '1',
  `provision_status` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`userdirectoryid`),
  KEY `userdirectory_1` (`idp_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userdirectory`
--

LOCK TABLES `userdirectory` WRITE;
/*!40000 ALTER TABLE `userdirectory` DISABLE KEYS */;
/*!40000 ALTER TABLE `userdirectory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userdirectory_idpgroup`
--

DROP TABLE IF EXISTS `userdirectory_idpgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userdirectory_idpgroup` (
  `userdirectory_idpgroupid` bigint unsigned NOT NULL,
  `userdirectoryid` bigint unsigned NOT NULL,
  `roleid` bigint unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`userdirectory_idpgroupid`),
  KEY `userdirectory_idpgroup_1` (`userdirectoryid`),
  KEY `userdirectory_idpgroup_2` (`roleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userdirectory_idpgroup`
--

LOCK TABLES `userdirectory_idpgroup` WRITE;
/*!40000 ALTER TABLE `userdirectory_idpgroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `userdirectory_idpgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userdirectory_ldap`
--

DROP TABLE IF EXISTS `userdirectory_ldap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userdirectory_ldap` (
  `userdirectoryid` bigint unsigned NOT NULL,
  `host` varchar(255) NOT NULL DEFAULT '',
  `port` int NOT NULL DEFAULT '389',
  `base_dn` varchar(255) NOT NULL DEFAULT '',
  `search_attribute` varchar(128) NOT NULL DEFAULT '',
  `bind_dn` varchar(255) NOT NULL DEFAULT '',
  `bind_password` varchar(128) NOT NULL DEFAULT '',
  `start_tls` int NOT NULL DEFAULT '0',
  `search_filter` varchar(255) NOT NULL DEFAULT '',
  `group_basedn` varchar(255) NOT NULL DEFAULT '',
  `group_name` varchar(255) NOT NULL DEFAULT '',
  `group_member` varchar(255) NOT NULL DEFAULT '',
  `user_ref_attr` varchar(255) NOT NULL DEFAULT '',
  `group_filter` varchar(255) NOT NULL DEFAULT '',
  `group_membership` varchar(255) NOT NULL DEFAULT '',
  `user_username` varchar(255) NOT NULL DEFAULT '',
  `user_lastname` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`userdirectoryid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userdirectory_ldap`
--

LOCK TABLES `userdirectory_ldap` WRITE;
/*!40000 ALTER TABLE `userdirectory_ldap` DISABLE KEYS */;
/*!40000 ALTER TABLE `userdirectory_ldap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userdirectory_media`
--

DROP TABLE IF EXISTS `userdirectory_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userdirectory_media` (
  `userdirectory_mediaid` bigint unsigned NOT NULL,
  `userdirectoryid` bigint unsigned NOT NULL,
  `mediatypeid` bigint unsigned NOT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(255) NOT NULL DEFAULT '',
  `active` int NOT NULL DEFAULT '0',
  `severity` int NOT NULL DEFAULT '63',
  `period` varchar(1024) NOT NULL DEFAULT '1-7,00:00-24:00',
  PRIMARY KEY (`userdirectory_mediaid`),
  KEY `userdirectory_media_1` (`userdirectoryid`),
  KEY `userdirectory_media_2` (`mediatypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userdirectory_media`
--

LOCK TABLES `userdirectory_media` WRITE;
/*!40000 ALTER TABLE `userdirectory_media` DISABLE KEYS */;
/*!40000 ALTER TABLE `userdirectory_media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userdirectory_saml`
--

DROP TABLE IF EXISTS `userdirectory_saml`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userdirectory_saml` (
  `userdirectoryid` bigint unsigned NOT NULL,
  `idp_entityid` varchar(1024) NOT NULL DEFAULT '',
  `sso_url` varchar(2048) NOT NULL DEFAULT '',
  `slo_url` varchar(2048) NOT NULL DEFAULT '',
  `username_attribute` varchar(128) NOT NULL DEFAULT '',
  `sp_entityid` varchar(1024) NOT NULL DEFAULT '',
  `nameid_format` varchar(2048) NOT NULL DEFAULT '',
  `sign_messages` int NOT NULL DEFAULT '0',
  `sign_assertions` int NOT NULL DEFAULT '0',
  `sign_authn_requests` int NOT NULL DEFAULT '0',
  `sign_logout_requests` int NOT NULL DEFAULT '0',
  `sign_logout_responses` int NOT NULL DEFAULT '0',
  `encrypt_nameid` int NOT NULL DEFAULT '0',
  `encrypt_assertions` int NOT NULL DEFAULT '0',
  `group_name` varchar(255) NOT NULL DEFAULT '',
  `user_username` varchar(255) NOT NULL DEFAULT '',
  `user_lastname` varchar(255) NOT NULL DEFAULT '',
  `scim_status` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`userdirectoryid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userdirectory_saml`
--

LOCK TABLES `userdirectory_saml` WRITE;
/*!40000 ALTER TABLE `userdirectory_saml` DISABLE KEYS */;
/*!40000 ALTER TABLE `userdirectory_saml` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userdirectory_usrgrp`
--

DROP TABLE IF EXISTS `userdirectory_usrgrp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userdirectory_usrgrp` (
  `userdirectory_usrgrpid` bigint unsigned NOT NULL,
  `userdirectory_idpgroupid` bigint unsigned NOT NULL,
  `usrgrpid` bigint unsigned NOT NULL,
  PRIMARY KEY (`userdirectory_usrgrpid`),
  UNIQUE KEY `userdirectory_usrgrp_1` (`userdirectory_idpgroupid`,`usrgrpid`),
  KEY `userdirectory_usrgrp_2` (`usrgrpid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userdirectory_usrgrp`
--

LOCK TABLES `userdirectory_usrgrp` WRITE;
/*!40000 ALTER TABLE `userdirectory_usrgrp` DISABLE KEYS */;
/*!40000 ALTER TABLE `userdirectory_usrgrp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `userid` bigint unsigned NOT NULL,
  `username` varchar(100) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `surname` varchar(100) NOT NULL DEFAULT '',
  `passwd` varchar(60) NOT NULL DEFAULT '',
  `url` varchar(2048) NOT NULL DEFAULT '',
  `autologin` int NOT NULL DEFAULT '0',
  `autologout` varchar(32) NOT NULL DEFAULT '15m',
  `lang` varchar(7) NOT NULL DEFAULT 'default',
  `refresh` varchar(32) NOT NULL DEFAULT '30s',
  `theme` varchar(128) NOT NULL DEFAULT 'default',
  `attempt_failed` int NOT NULL DEFAULT '0',
  `attempt_ip` varchar(39) NOT NULL DEFAULT '',
  `attempt_clock` int NOT NULL DEFAULT '0',
  `rows_per_page` int NOT NULL DEFAULT '50',
  `timezone` varchar(50) NOT NULL DEFAULT 'default',
  `roleid` bigint unsigned DEFAULT NULL,
  `userdirectoryid` bigint unsigned DEFAULT NULL,
  `ts_provisioned` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `users_1` (`username`),
  KEY `users_2` (`userdirectoryid`),
  KEY `users_3` (`roleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_groups` (
  `id` bigint unsigned NOT NULL,
  `usrgrpid` bigint unsigned NOT NULL,
  `userid` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_groups_1` (`usrgrpid`,`userid`),
  KEY `users_groups_2` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_groups`
--

LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usrgrp`
--

DROP TABLE IF EXISTS `usrgrp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usrgrp` (
  `usrgrpid` bigint unsigned NOT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `gui_access` int NOT NULL DEFAULT '0',
  `users_status` int NOT NULL DEFAULT '0',
  `debug_mode` int NOT NULL DEFAULT '0',
  `userdirectoryid` bigint unsigned DEFAULT NULL,
  `mfa_status` int NOT NULL DEFAULT '0',
  `mfaid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`usrgrpid`),
  UNIQUE KEY `usrgrp_1` (`name`),
  KEY `usrgrp_2` (`userdirectoryid`),
  KEY `usrgrp_3` (`mfaid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usrgrp`
--

LOCK TABLES `usrgrp` WRITE;
/*!40000 ALTER TABLE `usrgrp` DISABLE KEYS */;
/*!40000 ALTER TABLE `usrgrp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `valuemap`
--

DROP TABLE IF EXISTS `valuemap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `valuemap` (
  `valuemapid` bigint unsigned NOT NULL,
  `hostid` bigint unsigned NOT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `uuid` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`valuemapid`),
  UNIQUE KEY `valuemap_1` (`hostid`,`name`),
  KEY `valuemap_2` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `valuemap`
--

LOCK TABLES `valuemap` WRITE;
/*!40000 ALTER TABLE `valuemap` DISABLE KEYS */;
/*!40000 ALTER TABLE `valuemap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `valuemap_mapping`
--

DROP TABLE IF EXISTS `valuemap_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `valuemap_mapping` (
  `valuemap_mappingid` bigint unsigned NOT NULL,
  `valuemapid` bigint unsigned NOT NULL,
  `value` varchar(64) NOT NULL DEFAULT '',
  `newvalue` varchar(64) NOT NULL DEFAULT '',
  `type` int NOT NULL DEFAULT '0',
  `sortorder` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`valuemap_mappingid`),
  UNIQUE KEY `valuemap_mapping_1` (`valuemapid`,`value`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `valuemap_mapping`
--

LOCK TABLES `valuemap_mapping` WRITE;
/*!40000 ALTER TABLE `valuemap_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `valuemap_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widget`
--

DROP TABLE IF EXISTS `widget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widget` (
  `widgetid` bigint unsigned NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `x` int NOT NULL DEFAULT '0',
  `y` int NOT NULL DEFAULT '0',
  `width` int NOT NULL DEFAULT '1',
  `height` int NOT NULL DEFAULT '2',
  `view_mode` int NOT NULL DEFAULT '0',
  `dashboard_pageid` bigint unsigned NOT NULL,
  PRIMARY KEY (`widgetid`),
  KEY `widget_1` (`dashboard_pageid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widget`
--

LOCK TABLES `widget` WRITE;
/*!40000 ALTER TABLE `widget` DISABLE KEYS */;
/*!40000 ALTER TABLE `widget` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widget_field`
--

DROP TABLE IF EXISTS `widget_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widget_field` (
  `widget_fieldid` bigint unsigned NOT NULL,
  `widgetid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `value_int` int NOT NULL DEFAULT '0',
  `value_str` varchar(2048) NOT NULL DEFAULT '',
  `value_groupid` bigint unsigned DEFAULT NULL,
  `value_hostid` bigint unsigned DEFAULT NULL,
  `value_itemid` bigint unsigned DEFAULT NULL,
  `value_graphid` bigint unsigned DEFAULT NULL,
  `value_sysmapid` bigint unsigned DEFAULT NULL,
  `value_serviceid` bigint unsigned DEFAULT NULL,
  `value_slaid` bigint unsigned DEFAULT NULL,
  `value_userid` bigint unsigned DEFAULT NULL,
  `value_actionid` bigint unsigned DEFAULT NULL,
  `value_mediatypeid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`widget_fieldid`),
  KEY `widget_field_1` (`widgetid`),
  KEY `widget_field_2` (`value_groupid`),
  KEY `widget_field_3` (`value_hostid`),
  KEY `widget_field_4` (`value_itemid`),
  KEY `widget_field_5` (`value_graphid`),
  KEY `widget_field_6` (`value_sysmapid`),
  KEY `widget_field_7` (`value_serviceid`),
  KEY `widget_field_8` (`value_slaid`),
  KEY `widget_field_9` (`value_userid`),
  KEY `widget_field_10` (`value_actionid`),
  KEY `widget_field_11` (`value_mediatypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widget_field`
--

LOCK TABLES `widget_field` WRITE;
/*!40000 ALTER TABLE `widget_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `widget_field` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-09 21:58:37
